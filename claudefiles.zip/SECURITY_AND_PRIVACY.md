# Security & Privacy Plan

> Not legal advice. Laws differ by country and change. Before launch, have a lawyer in your target markets review your EULA, privacy policy, and consent flow.

Sentinel handles **video of people's homes/workplaces** and **biometric templates (face embeddings)**. That makes it a high-trust product: one security incident or one privacy scandal can end it. Build trust into the design, not as a later patch.

---

## 1. Assets and threats

| Asset | Why it matters |
|-------|----------------|
| Camera streams and credentials (`rtsp://user:pass@…`) | Access to the inside of people's homes |
| Face embeddings and enrolment photos | Biometric data; cannot be "reset" like a password |
| Snapshots / event history | Reveals when people are home, who visits |
| Admin account and session | Controls everything above |
| Notification channel secrets (SMTP password, bot tokens, VAPID private key) | Impersonation, spam, data exfiltration |
| Licence signing private key (yours) | Lets anyone mint licences |

| Threat | Example | Primary controls |
|--------|---------|------------------|
| Someone on the same network | Open dashboard on `0.0.0.0` with no login (**today**) | Auth, bind to localhost by default, CSRF |
| Internet exposure | Customer port-forwards the dashboard | Warn loudly; recommend VPN/Tailscale; HTTPS; rate limiting; never expose by default |
| Stolen laptop / backup | DB and snapshots read offline | Encrypt secrets at rest; optional disk encryption guidance; encrypted exports |
| Malicious/curious camera URL | `file:///etc/passwd`, internal service probing | Allow-list schemes (`rtsp`, `rtsps`, `http`, `https`, USB index, uploads-dir files only) |
| Tampered data file | `pickle` RCE (**today**) | No `pickle`; raw `float32` bytes |
| Supply chain | Malicious or vulnerable dependency | Pin versions, `pip-audit` in CI, minimal deps |
| Leaked secrets in git | Telegram token (**today**) | `.env`, secret scanning (`gitleaks`/GitHub push protection), rotate on leak |
| Spoofing the face matcher | Photo/phone screen | Disclose; don't market as access control; later: liveness detection |
| Your own server (when relay exists) | Mass compromise | Don't build one until needed; end-to-end encrypt payloads |

---

## 2. MVP security requirements (must-have before any paid customer)

### Authentication & sessions
- [ ] First-run wizard creates the admin account; **no default credentials**
- [ ] Passwords hashed with **argon2id** (or bcrypt); minimum length 10; no composition rules
- [ ] Login rate-limiting + temporary lockout; generic error messages
- [ ] Session cookie: `HttpOnly`, `SameSite=Lax`, `Secure` when HTTPS; idle + absolute timeouts
- [ ] **CSRF token** on every state-changing request (forms and HTMX)
- [ ] Roles: `admin`, `viewer`. Viewers can't change settings, manage faces, or see credentials
- [ ] "Change password" and "log out everywhere"
- [ ] Password reset = CLI command on the host (`sentinel reset-password`), no email flow in v1

### Network
- [ ] Default bind **`127.0.0.1`**; LAN access = explicit toggle with a warning
- [ ] Documented HTTPS setup (reverse proxy such as Caddy, or built-in self-signed option)
- [ ] Security headers: `Content-Security-Policy`, `X-Content-Type-Options`, `Referrer-Policy`, `X-Frame-Options`/`frame-ancestors`
- [ ] Never serve snapshot files as static public files; serve through an authenticated route

### Secrets & data at rest
- [ ] No secrets in source; `.env.example` only; CI secret scanning
- [ ] Camera URLs and channel credentials **encrypted in the DB** (Fernet; key from env or OS keyring; generated at first run)
- [ ] Secrets **masked in logs, UI, and diagnostics bundles**
- [ ] Embeddings stored as raw bytes (no `pickle`)
- [ ] Snapshot/crop directory outside the web root; restrictive file permissions; retention sweeper
- [ ] Encrypted backup/export option; clear docs on where data lives

### Input & dependencies
- [ ] Validate all input with Pydantic; upload checks (type, size, image decode, dimension limits)
- [ ] Parameterised SQL / ORM only (your existing code already uses `?` parameters, so keep it that way)
- [ ] `pip-audit` + `ruff` + `bandit` in CI; pin dependencies; update monthly
- [ ] Camera URL scheme allow-list (see above)

### Operational
- [ ] **Audit log**: logins, failed logins, face enrol/delete, camera add/remove, settings changes, exports
- [ ] **Download diagnostics** with secrets stripped
- [ ] Update mechanism checks signatures/hashes of releases
- [ ] Vulnerability disclosure contact (`security@…`, `SECURITY.md` in the repo)

---

## 3. Privacy & biometric data

### Principles
1. **Data minimisation.** Store embeddings, not more than needed. Enrolment photos are *optional* (needed only to re-enrol after a model change); let the owner choose.
2. **Local by default.** Nothing leaves the machine unless the owner configures a channel. Say so plainly in the UI and website, and make it true: no analytics without explicit opt-in.
3. **Consent is a feature.** Adding a person requires ticking "this person has agreed to be recognised" (`consent_at` stored). Provide a printable notice/sign template ("This area is monitored by video and face recognition").
4. **Retention by default.** Events and snapshots auto-delete after N days (default 30). Unknown-face crops default to 7 days.
5. **Real deletion.** "Delete person" removes embeddings, photos, and optionally their event history. "Delete all data" and "Export my data" exist.
6. **Transparency for the people being recognised.** Give owners ready-made text they can show.

### Regulatory landscape (starting points to research with a lawyer)
- **EU/UK GDPR:** face templates used to identify a person are *special category* biometric data (Art. 9). Household exemption may apply to purely personal home use, but **not** to businesses or to cameras covering public/neighbours' space. Requires a lawful basis (typically explicit consent), a retention policy, and often a data protection impact assessment.
- **India: Digital Personal Data Protection Act, 2023:** consent- and notice-based processing of personal data; check current rules/notifications for obligations on data fiduciaries vs. a software vendor who never receives the data.
- **US:** Illinois BIPA (written consent, retention schedule, private right of action), plus Texas and Washington biometric laws and CCPA/CPRA in California. Several municipalities restrict face recognition.
- **Workplaces / shops:** typically stricter than homes: signage, employee notice, sometimes works-council or union consultation.

**Why local-first helps:** if you never receive customers' biometric data, you are generally the *software vendor*, not the *processor* of that data, which greatly reduces your own exposure. Your obligations shift to (a) honest marketing, (b) shipping privacy-protective defaults, and (c) clear terms that the **customer** is responsible for lawful use. Confirm this analysis with a lawyer for each market you sell in.

### Responsible-use positioning
- Market as **"know who's at your door / premises"**, not as "identify strangers" or "track people".
- No covert-surveillance features (no hidden mode, no stalking-friendly features such as tracking a person across cameras by default).
- EULA: prohibit unlawful surveillance; customer is responsible for notices/consent.
- State accuracy limits and the lack of liveness detection in the docs.
- Don't claim "bank-grade", "military-grade", "100% accurate", or "secure access control."

### Telemetry policy
Default **off**. If you add anonymous crash reports/usage stats, make them opt-in, documented field by field, and free of images, names, URLs, and IPs.

---

## 4. Incident readiness

| Scenario | Prepare now |
|----------|-------------|
| A vulnerability is reported | `SECURITY.md` with contact + 90-day disclosure policy; ability to ship a patched build within days |
| A customer's secrets leaked | In-app "rotate all secrets" button; docs for revoking camera passwords |
| Your signing key leaks | Key stored offline/password manager; plan to rotate public key with an app update |
| Bad release corrupts a DB | Pre-migration auto-backup; documented restore |

---

## 5. Pre-launch security review

Do a final pass using the `/code-review` lens on: auth flows, every route that changes state, file upload/serve paths, camera URL handling, log output, backup/export, update/licensing code. Then run `pip-audit`, `bandit -r src`, and `gitleaks detect` and fix everything high/critical. Consider paying for one independent penetration test or code audit before you charge businesses.
