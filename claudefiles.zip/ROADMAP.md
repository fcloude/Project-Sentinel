# Project Sentinel: Roadmap (Prototype → Sellable MVP)

**Goal:** a product a non-developer can install in 15 minutes, connect any camera, teach it many faces, and get alerts from Sentinel's own notification system, safe and legal to sell.

**Pace assumption:** one developer, part-time, learning as you go → **~14 weeks to a paid beta**. If you work full-time on it, halve the calendar time but keep the order. Treat week numbers as *effort*, not deadlines.

**How to use this:** work top to bottom. Don't start a phase until the previous phase's *exit criteria* are true. Every task is small enough to finish in 1–3 sessions.

> Read first: [docs/CODE_REVIEW.md](docs/CODE_REVIEW.md) (what's wrong today) · [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) (where we're going) · [docs/DECISIONS.md](docs/DECISIONS.md) (why)

---

## MVP definition

**In scope**
- Login-protected web dashboard (setup wizard, no default password)
- Multiple cameras: USB, RTSP/IP, phone-app streams, video file
- Motion → person detection → face recognition with **multiple people × multiple photos each**
- Unknown-face inbox ("Who is this?")
- Events timeline with snapshots
- Notifications: in-app, Web Push (PWA), email, webhook, optional bring-your-own Telegram; rules with cooldown + quiet hours
- Retention + delete-my-data; encrypted secrets
- Docker image + Windows installer; licence key; docs + landing page

**Out of scope (post-MVP)**
Continuous recording / video clips · native mobile app · cloud relay · ONVIF auto-discovery · liveness detection · multi-site · licence-plate recognition · GPU/NPU optimisation

---

## Phase 0: Stop the bleeding (Week 1)

*Make the repo safe and runnable. No new features.*

- [ ] **Revoke the Telegram bot token** via @BotFather (`/revoke`); store the new one in `.env`
- [ ] Remove hardcoded secrets from `notifications/settings.py` and `telegram_test.py`; add `.env.example`; replace `.gitignore` with the provided one (adds `*.db`, `snapshots/`, `*.bak`, `*.pt`, `data/`)
- [ ] Optional: scrub git history (`git filter-repo`) or start a fresh private repo
- [ ] Delete: all `*.bak`, `tools/fix_imports.py`, empty stub files, pseudo-code files (list in `PROJECT_SOURCE.md`)
- [ ] Add `pyproject.toml`; `pip install -e .`; imports are now `from sentinel...` and never need rewriting again
- [ ] Add `ruff` + `pytest`; first CI run on GitHub Actions
- [ ] Fix the quick bugs: `migration.py` SyntaxError, `Event.timestamp.isoformat`, `EventBus.publish` exception isolation, remove `print`s, single DB path + `makedirs`
- [ ] Replace `MockCamera` with `FileCamera` that loops a short `sample.mp4`; get `main.py` running **without a webcam**
- [ ] Write the **first real test**: feed `sample.mp4`, assert at least one `MOTION_DETECTED` event is published

**Exit criteria:** `pytest` is green in CI; no secrets in the repo; the engine runs end-to-end from a video file.
**Learn:** git basics for secrets, `pyproject.toml`, `pytest` fixtures.

---

## Phase 1: Foundation (Weeks 2–4)

*Real web app, real database, real cameras.*

**1A. App skeleton (Week 2)**
- [ ] FastAPI app factory + `lifespan` (engine created at startup, not at import)
- [ ] `pydantic-settings` for configuration; fail fast with clear messages
- [ ] SQLAlchemy models + **Alembic** first migration (tables in `ARCHITECTURE.md` §5)
- [ ] Persist every event via a `"*"` subscriber; save snapshot path with event
- [ ] **Auth:** setup wizard, argon2 password hash, session cookie, CSRF, login rate-limit, bind `127.0.0.1`
- [ ] Port `/` and engine start/stop/restart with HTMX (no full-page reload) and a real `/api/health`

**1B. Cameras (Weeks 3–4)**
- [ ] `CameraSource` interface + `OpenCVSource` (USB, RTSP, HTTP, file)
- [ ] `CameraWorker`: reader thread, latest-frame slot, reconnect with backoff, status states
- [ ] Camera registry in DB; credentials encrypted (Fernet)
- [ ] **Add Camera UI** with **Test connection** (shows one frame), URL templates for common brands, masked credentials
- [ ] Live view as MJPEG in the dashboard; camera tiles with online/offline status
- [ ] Multiple cameras running at once, each with its own `MotionDetector`
- [ ] Remove `cv2.imshow` from the engine
- [ ] Test with: your webcam, your phone (IP-webcam-type app), and one RTSP source (a real camera, or run a local RTSP test server)

**Exit criteria:** log in → add two different cameras → see both live → unplug one → it shows "reconnecting" and recovers by itself.
**Learn:** FastAPI tutorial (routing, dependencies, security, background tasks), SQLAlchemy 2.0 tutorial, Alembic basics, how RTSP URLs work, OpenCV `VideoCapture`.
**Decision gate:** pick your niche (A/B/C/D in `docs/BUSINESS_AND_LICENSING.md`) after 10 user conversations.

---

## Phase 2: Recognition that can be sold (Weeks 5–7)

*Legal models, many faces, good accuracy.*

- [ ] **Interfaces:** `PersonDetector`, `FaceRecognizer` (swappable models)
- [ ] **ADR-004 gate:** assemble a consented test set; write `scripts/benchmark.py` (accuracy + ms/frame); evaluate YuNet+SFace and a permissive ONNX person detector (then AuraFace if needed). Decide. **Remove `ultralytics`/`buffalo_l` from the dependency list.**
- [ ] `people` + `face_embeddings` tables (multiple embeddings per person, `model_id`, `consent_at`)
- [ ] **Enrolment:** upload 3–5 photos *or* capture from a camera; quality checks with friendly rejection reasons
- [ ] In-memory `FaceIndex` (matrix match), reload on enrol/delete; margin-to-second-best rule
- [ ] Run faces **once per frame** on person crops; per-camera, per-identity cooldown
- [ ] **Unknown-face inbox:** dedupe, thumbnails, "Name this person" / dismiss
- [ ] Threshold slider (strict / balanced / lenient)
- [ ] Shared inference worker with bounded queue; detection FPS cap per camera; use the camera sub-stream for detection
- [ ] People UI: list, add photos, delete person (real delete)
- [ ] Publish measured performance for your reference machine

**Exit criteria:** on your test set, you can state numbers ("X% correct, Y false-accepts per 1000 unknown faces") and a licence-clean dependency list; 4 cameras run at target FPS on the reference machine.
**Learn:** what an embedding and cosine similarity are, precision vs recall, ONNX Runtime, NumPy matrix ops.

---

## Phase 3: Notifications (Weeks 8–9)

*Sentinel's own alert system.*

- [ ] `NotificationChannel` interface, rule model, **outbox table + worker pool** with retry/backoff
- [ ] Channels in this order: **In-app (SSE + notification centre + sound)** → **Webhook** → **Email (SMTP)** → **Web Push (PWA, VAPID)** → **Telegram (bring-your-own token)**
- [ ] Rule engine: trigger type, cameras, time window, cooldown per (rule, camera, person), attach snapshot
- [ ] Ship 3 default rules ("Unknown person", "Known person arrives", "Camera offline")
- [ ] "Send test" per channel; failure reasons visible in UI
- [ ] PWA manifest + service worker; document HTTPS requirement and iOS "Add to Home Screen"
- [ ] **Spike Windows packaging now** (PyInstaller or similar + a service wrapper), because it's the riskiest unknown

**Exit criteria:** a stranger walks in front of the camera → phone shows an alert with a snapshot within ~5 s; killing the internet and restoring it delivers queued alerts without engine crashes.
**Learn:** Server-Sent Events, Web Push + service workers (MDN), SMTP, retry/backoff patterns.

---

## Phase 4: Product polish: UI/UX, privacy, reliability (Weeks 10–11)

- [ ] **Setup wizard** (admin → camera → yourself as person → channel → test alert)
- [ ] Dashboard "is everything OK?" overview; events timeline with filters + thumbnails; empty states; error toasts; mobile layout; dark mode
- [ ] Settings: retention, thresholds, bind/LAN access toggle with warning, notification quiet hours
- [ ] Privacy features: consent checkbox + printable notice, retention sweeper, "export my data", "delete all data"
- [ ] Audit log page; encrypted export/backup
- [ ] System page + **Download diagnostics** (secrets stripped)
- [ ] Disk-space guard; log rotation; auto-restart behaviour
- [ ] Accessibility pass (contrast, labels, keyboard)
- [ ] Usability test: 3 people who've never seen it install and reach a first alert; fix what confuses them

**Exit criteria:** a non-developer completes setup alone, in < 15 minutes, with no help.

---

## Phase 5: Package, protect, sell (Weeks 12–14)

- [ ] Dockerfile (non-root, healthcheck) + `docker-compose.yml`
- [ ] Windows installer (+ code signing if feasible); auto-start on boot; "check for updates" notice
- [ ] `licensing/` verify (Ed25519 signed key; tier limits); key-issue script; trial mode
- [ ] `THIRD_PARTY_LICENSES.md`, EULA, privacy policy, `SECURITY.md`
- [ ] Docs site: install per OS, "find your camera's RTSP URL" guide, troubleshooting, privacy/consent guide, supported hardware table
- [ ] Landing page + demo video + pricing + payment provider (merchant of record) + refund policy
- [ ] Run `docs/DEPLOY_CHECKLIST.md` section A (first-release gate) in full
- [ ] **Closed beta:** 5–10 users × 4 weeks → fix → first paid customers

**Exit criteria:** a stranger can find the page, pay, download, install, and get an alert, and you didn't touch anything manually except issuing the licence key.

---

## Phase 6: After the MVP (pick based on customer pull, not hunches)

| Candidate | Trigger to build it |
|-----------|---------------------|
| Event **clips** (pre/post-roll video) | Customers ask "what did they do?" |
| ONVIF auto-discovery | Setup support tickets about RTSP URLs |
| **Cloud relay** (remote access + push when away) → paid add-on | Repeated "works at home but not outside" requests |
| Daily/weekly **email digest** & attendance reports | Business-niche customers |
| Detection **zones**, line-crossing | Noise complaints from busy scenes |
| Hardware acceleration (OpenVINO/CUDA/Hailo) | Camera count limited by CPU |
| Liveness / anti-spoofing | Customers want door-access use cases |
| Native mobile app | Push/UX complaints justify the cost |
| Plugin API, i18n/localisation | Community asks; new-market expansion |

---

## Risk register

| Risk | Mitigation | Phase |
|------|------------|-------|
| Model licences block selling | ADR-004 gate; budget fallback for paid licences | 2 |
| Free competitors (Frigate etc.) | Niche + polish + support; validate with real users early | 1 |
| RTSP/camera compatibility variety | Test several real cameras; URL templates; diagnostics bundle | 1 |
| CPU too weak for N cameras | Motion gate, sub-streams, FPS caps, publish measured limits | 2 |
| Windows packaging problems | Spike in Phase 3; Docker as fallback | 3 |
| Privacy/legal exposure | Local-first, consent features, retention defaults, lawyer review | 4–5 |
| Burnout / scope creep | Strict MVP list above; "post-MVP" parking lot; finish phases | all |

---

## Suggested weekly rhythm
- **Mon–Thu:** build one vertical slice (UI + API + DB + test) for the current phase
- **Fri:** review the exit criteria, update this file's checkboxes, write the changelog entry
- **Every 2 weeks:** show a screen recording to 2–3 target users and write down their reactions

## Definition of Done (every task)
Works from a clean install · has a test or a documented manual check · errors are visible to the user, not just the log · no secrets in code or logs · docs/CHANGELOG updated · `ruff` + `pytest` pass.
