# Business, Licensing & Go-To-Market

> Everything about prices, markets, and legal structure here is **a hypothesis to test**, not a fact. The two licensing findings in §1 were checked against upstream sources on 2026-10-29; re-verify before launch. Not legal advice.

---

## 1. Two hard blockers (fix before charging anyone)

### 1.1 InsightFace models: non-commercial only
Your code loads `FaceAnalysis(name="buffalo_l")`. The InsightFace **Python library** is MIT, but the **pretrained model packs it downloads** (`buffalo_l`, `buffalo_s`, `antelopev2`, …) are released for **non-commercial research purposes only**. Selling software that ships or downloads them would violate that.

**Options:** switch to permissively licensed models (YuNet + SFace through OpenCV; AuraFace + YuNet), or negotiate a commercial licence with InsightFace. See ADR-004.

### 1.2 Ultralytics YOLOv8: AGPL-3.0
`from ultralytics import YOLO` with `yolov8n.pt` is AGPL-3.0 (code and default weights). Using it inside a closed-source commercial product requires an **Ultralytics Enterprise License**; otherwise your whole product must be offered under AGPL-3.0 (source available to users, including network users).

**Options:** (a) buy the Enterprise licence, (b) swap to a permissive detector exported to ONNX (my recommendation, which also removes PyTorch's multi-GB footprint), (c) go open-source/AGPL and sell support, hosting, hardware, or a paid edition.

### 1.3 Dependency licence audit
Run this on your final environment and keep the output in `THIRD_PARTY_LICENSES.md`:

```bash
pip install pip-licenses
pip-licenses --format=markdown --with-urls --with-license-file --no-license-path > THIRD_PARTY_LICENSES.md
```
Anything GPL / AGPL / "non-commercial" / "research only" must be replaced, licensed, or isolated. Also check **model weight licences separately from code licences**, since they are often different. Items I'd verify specifically: OpenCV (Apache-2.0 for recent versions), ONNX Runtime, `python-telegram-bot` (LGPL), any detector checkpoint you pick, any icon/font/CSS you ship.

---

## 2. Market reality check

You are not entering an empty field. As of the searches I ran today:

| Product | Model | Relevance |
|---------|-------|-----------|
| **Frigate** | Free, open-source, self-hosted NVR with AI object detection; face and licence-plate recognition built in since v0.16 (current docs mention 0.17); large community; strong Home Assistant integration | The benchmark. Powerful but configuration-heavy (Docker + YAML) |
| **Viseron** | Free, MIT, self-hosted NVR with built-in face recognition | Closest feature match |
| **Double Take + CompreFace** | Open source face-recognition layer on top of NVRs | Popular add-on pattern |
| **Blue Iris** | Paid, Windows NVR | Proves people pay for a polished Windows product |
| **ZoneMinder, Shinobi, Agent DVR** | Free/OSS (some paid tiers) | Older, broader NVRs |
| **Ring / Nest / Arlo / Wyze** | Cloud subscriptions | What mainstream consumers actually use |

**Implication:** "AI camera with face recognition" is **not** a gap. A free Frigate install already does most of it. You win, if you win, on **ease, polish, and a specific audience**, not on features. Be honest with yourself about this before investing months.

### Candidate niches (pick one by end of Phase 1)

| Niche | Who | Why it might work | Risks |
|-------|-----|-------------------|-------|
| **A. "Frigate for non-technical people"** | Homeowners, tinkerers who can't/won't write YAML | One-click installer, setup wizard, a clean UI, phone alerts that just work | Price-sensitive buyers; free alternative exists |
| **B. Visitor & attendance log for small businesses** | Shops, clinics, coaching centres, small offices, gyms, co-working spaces | "Who came and when, who's a stranger" + a daily email report. Businesses pay more than consumers and value reports | Biometric consent/labour law complexity; accuracy expectations; support load |
| **C. "Who's at my door" for families/elders** | Families with elderly relatives, shop owners | Simple story, emotional value | Competes with Ring-style doorbells |
| **D. Regional/local-language, local-pricing** | Markets underserved by English-first, subscription-priced tools | Localisation + local payment methods + support in the local language | Smaller willingness to pay per customer; piracy |

**How to decide without guessing:** do **10–15 conversations** with real people in your top 2 niches *before* building the UI. Ask what they use today, what annoys them, what they'd pay, and where they'd run it. Show them a clickable mock. A pre-order or a waitlist email is a stronger signal than "sounds cool."

---

## 3. Pricing (hypotheses to test)

Model: **licence key unlocking limits**, not feature-crippling.

| Tier | Limits | Illustrative price (test it!) |
|------|--------|-------------------------------|
| Free / Trial | 1 camera, 3 people, 14–30 day full-feature trial or permanent small free tier | $0 |
| Home | 4 cameras, 20 people | One-time ~$49–79 *or* ~$29/yr for updates |
| Business | 8–16 cameras, 500 people, email reports, priority support | ~$149–299/yr per site |
| *(later)* Relay add-on | Remote access + push when away | ~$3–8/month |

Notes:
- One-time prices attract users but give no recurring revenue; sell **1 year of updates** with the right to keep the last version.
- Consider **regional pricing** and local payment methods if your buyers are price-sensitive.
- Per-camera limits are easy to explain and enforce.
- Offer a **money-back window** (14–30 days). It lowers purchase anxiety and costs little.

---

## 4. How to actually sell it online

1. **Landing page** (one page): headline, 60-second demo video/GIF, 3 benefits, "works with your existing cameras", privacy promise (data never leaves your machine), pricing, FAQ, download/buy button.
2. **Merchant of record** (Paddle, Lemon Squeezy, or a simpler option like Gumroad for early tests) so global sales tax/VAT is handled for you. Confirm your country is supported for payouts.
3. **Licence delivery:** after payment, a webhook (or a manual script at first) generates a signed licence key and emails it. Manual for the first 20 customers is fine.
4. **Downloads:** GitHub Releases (private or public binary releases), or object storage; publish SHA-256 checksums; code-sign the Windows installer when you can afford a certificate (unsigned installers trigger scary SmartScreen warnings and hurt conversion).
5. **Docs site:** install guide per OS, "supported cameras + how to find your RTSP URL" (this page will bring you organic search traffic), troubleshooting, FAQ, privacy/consent guide.
6. **Support channel:** one email + one community space (Discord/Reddit/GitHub Discussions). Add the "Download diagnostics" button.
7. **Distribution:** demo videos (YouTube), relevant communities (self-hosting and home-automation forums, with respect for their self-promotion rules), local business groups for niche B, comparison pages ("Sentinel vs Frigate: when to choose which"; honesty builds trust).
8. **Beta first:** 5–10 free beta users for 4 weeks → fix → first paying customers → iterate. Ask each for a short testimonial.

### Legal & business basics (talk to an accountant/lawyer in your country)
- Business registration / tax setup for receiving international payments.
- **EULA** (permitted use, no unlawful surveillance, no warranty, limitation of liability, customer responsible for consent/notices).
- **Privacy policy** (what the website collects; what the software does *not* collect).
- **Refund policy** and **support policy** (what's included, response times).
- **Trademark/name check:** "Sentinel" is an extremely common name in security software. Search trademark databases and app stores before investing in branding; a more distinctive name will also be easier to rank for.
- **Disclaimers:** not a certified alarm/safety system; no guarantee of detection; not for life-safety use.

---

## 5. Metrics that matter

| Stage | Metric | Rough target |
|-------|--------|--------------|
| Beta | Time from download to first real alert | < 15 min |
| Beta | % of installs that add a camera and a person | > 70% |
| Beta | Crash-free sessions | > 99% |
| Launch | Visitor → trial/download conversion | track, 2–5% typical for dev-ish tools |
| Launch | Trial → paid | track, 3–10% |
| Ongoing | Support tickets per customer | falling over time |
| Ongoing | Refund rate | < 5% |

(These are typical rule-of-thumb ranges, not guarantees; your niche will differ.)

---

## 6. Risks and honest mitigations

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| Free Frigate/Viseron is "good enough" | High | Pick a niche where polish + support matter; don't compete on features |
| Model licence problems | Certain if unaddressed | ADR-004 gate; budget for a paid licence if needed |
| Support burden swamps solo dev | High | Diagnostics button, good docs, supported-hardware table, limited OS targets |
| Face accuracy complaints (lighting, angles, masks) | Medium | Multi-photo enrolment, strict/lenient slider, honest docs, unknown-face inbox |
| Privacy/regulatory issue | Medium | Local-first, consent features, retention defaults, lawyer review per market |
| Windows packaging pain | Medium | Spike early (Phase 3), Docker as fallback |
| Piracy | Medium | Don't over-invest; value in updates and support |
| Scope creep (becoming a full NVR) | High | Snapshots + events first; clips later; no 24/7 recording in MVP |
