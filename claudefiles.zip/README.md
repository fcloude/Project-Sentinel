# 🛡️ Project Sentinel

**AI camera monitoring that tells you *who* is at your door, and keeps your video and faces on your own machine.**

Connect any camera, teach Sentinel the faces you know, and get alerts through its own notification system when someone unfamiliar shows up.

> **Status: prototype → MVP rebuild in progress.** The prototype (v0.x) proves the pipeline works. It is **not yet safe or licensed for production use**. See [ROADMAP.md](ROADMAP.md) for the plan and [docs/CODE_REVIEW.md](docs/CODE_REVIEW.md) for the honest state of the code.

---

## What it does (target MVP)

| | |
|---|---|
| 📷 **Any camera** | USB webcams, RTSP/IP cameras, phone-as-camera apps, video files. Several at once |
| 🧑‍🤝‍🧑 **Many faces** | Enrol as many people as you like, several photos each. Unknown faces land in an inbox for one-click naming |
| 🔔 **Its own notifications** | In-app alerts, browser/phone push, email, webhooks, and optionally your own Telegram bot, with rules, quiet hours and cooldowns |
| 🔒 **Private by design** | Runs locally. No cloud account. Login-protected dashboard. Encrypted credentials. Auto-delete retention |
| 🖥️ **Simple to set up** | First-run wizard: add camera → add yourself → add a notification channel → send a test alert |

**What it is not:** a door-lock or access-control system (no liveness detection, so a photo can fool it), a full 24/7 NVR, or a certified alarm.

---

## Current prototype: what exists today

Motion detection (OpenCV) → object detection (YOLO) → face detection + recognition (InsightFace) → events → Telegram alerts, with a small Flask dashboard.

**Known issues you should read before running it:** hardcoded Telegram token (revoke it), no dashboard login, database initialisation is broken, and two AI models are not licensed for commercial use. Details in [docs/CODE_REVIEW.md](docs/CODE_REVIEW.md).

---

## Quick start (developer preview, after Phase 0 fixes)

Requirements: Python 3.11+, a webcam or a short `sample.mp4`, Git.

```bash
git clone <your-private-repo-url> sentinel && cd sentinel

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install -e ".[dev]"            # installs the package + test tools

cp .env.example .env               # then edit it; never commit .env
python -c "import secrets; print(secrets.token_urlsafe(48))"   # paste as SECRET_KEY

python run.py                      # dashboard: http://127.0.0.1:5000
```

Run without a camera: set `CAMERA_SOURCE=file:tests/data/sample.mp4` in `.env`.
Run the tests: `pytest`

---

## Configuration

Environment variables (`.env`), see [.env.example](.env.example):

| Variable | Default | Purpose |
|----------|---------|---------|
| `SECRET_KEY` | *(required)* | Signs sessions and derives the secrets-encryption key |
| `DATABASE_PATH` | `data/sentinel.db` | SQLite database file |
| `HOST` / `PORT` | `127.0.0.1` / `5000` | Dashboard bind address. Change `HOST` only if you understand the risks |
| `LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `RETENTION_DAYS` | `30` | Auto-delete events and snapshots older than this |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` | *(empty)* | Optional bring-your-own Telegram channel |

Things you change while using the app (thresholds, rules, channels, cameras) live in the database and the Settings screen, not in `.env`.

> **Heads-up:** today's prototype only reads `APP_NAME`, `APP_VERSION`, `DEBUG`, `CAMERA_INDEX`, `DATABASE_PATH`, `LOG_LEVEL`, and `TELEGRAM_BOT_TOKEN` (see `src/config/loader.py`). `SECRET_KEY`, `HOST`/`PORT`, `RETENTION_DAYS`, `CAMERA_SOURCE`, and `TELEGRAM_CHAT_ID` are introduced during Phases 0–1 of the roadmap, and the quick start above assumes Phase 0 is done.

---

## Documentation

| Doc | What's inside |
|-----|---------------|
| [ROADMAP.md](ROADMAP.md) | Phased plan from prototype to a product you can sell, with exit criteria |
| [PROJECT_SOURCE.md](PROJECT_SOURCE.md) | Source-of-truth map: module-by-module, what to keep/refactor/delete, conventions |
| [docs/CODE_REVIEW.md](docs/CODE_REVIEW.md) | Review of the current code with prioritised issues and fix recipes |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | System design: cameras, pipeline, faces, notifications, data model, API |
| [docs/DECISIONS.md](docs/DECISIONS.md) | Architecture Decision Records (ADR-001 … 008) |
| [docs/SECURITY_AND_PRIVACY.md](docs/SECURITY_AND_PRIVACY.md) | Threat model, security checklist, biometric privacy |
| [docs/BUSINESS_AND_LICENSING.md](docs/BUSINESS_AND_LICENSING.md) | Model licensing blockers, competition, pricing hypotheses, how to sell |
| [docs/DEPLOY_CHECKLIST.md](docs/DEPLOY_CHECKLIST.md) | Release checklist and rollback triggers |

---

## Architecture at a glance

```
Cameras → CameraWorkers → Pipeline (motion → person → face → match)
                               │
                           Event Bus ─┬─► Event Store (SQLite)
                                      └─► Notification Service (rules → outbox → channels)
                                                  │
                         FastAPI web app ◄────────┘  (dashboard, API, live SSE)
```
More in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

---

## Privacy & responsible use

Face data is biometric data and is regulated in many places. Sentinel is designed so that **your video, snapshots and face templates stay on your device**, retention is automatic, and every enrolled person is recorded with a consent flag. You are responsible for lawful use, including notifying people who are monitored and obtaining consent where required. Don't use Sentinel for covert surveillance or to track people without their knowledge. See [docs/SECURITY_AND_PRIVACY.md](docs/SECURITY_AND_PRIVACY.md).

## Security

Found a vulnerability? Please email **security@your-domain.example** (placeholder; set before launch) rather than opening a public issue.

## Contributing

1. Branch from `main`: `feat/<name>` or `fix/<name>`
2. `ruff check . && ruff format . && pytest` must pass
3. Conventional commits (`feat(camera): …`, `fix(events): …`)
4. Update `CHANGELOG.md` and relevant docs
5. Never commit secrets, `.db` files, snapshots, or model weights

## Licence

**TBD before launch.** Depends on the model decision in ADR-004 (proprietary EULA vs. AGPL-3.0). Third-party licences will be listed in `THIRD_PARTY_LICENSES.md`.
