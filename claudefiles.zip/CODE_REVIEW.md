# Code Review: Project Sentinel Prototype

**Scope:** ~110 files uploaded from your GitHub repo (everything except `snapshots/` and `yolov8n.pt`)
**Method:** Static read of every file. I did **not** run the code (no camera or network in my sandbox). Two suspected bugs were confirmed by compiling/executing small reproductions (marked ✔ verified). Everything else is from reading the code, so test before trusting.
**Reviewer stance:** Senior engineer who wants this to become a sellable product.

---

## Summary

The prototype has a **good skeleton**: camera interface, event bus, repository pattern, a working motion → object → face → notify pipeline, and sensible package boundaries. That is the hard part to get right, and you did it.

But it is a prototype in every other sense: secrets are in source, the dashboard has no login, the database layer cannot initialise, one network hiccup kills the whole engine, and two of the AI models it depends on **cannot legally be sold** (see `BUSINESS_AND_LICENSING.md`). None of this is unusual for a 2–3 month old prototype. All of it is fixable, and most of it in Phase 0 of the roadmap.

**Verdict: 🔴 Request Changes.** Do not deploy, share the repo publicly, or sell it in its current state. Keep the architecture, rebuild the layers underneath.

---

## 🔴 Critical Issues

| # | File | Issue | Category |
|---|------|-------|----------|
| 1 | `src/notifications/settings.py`, `telegram_test.py` | **Telegram bot token and chat ID hardcoded in source.** Anyone with repo access (or git history) can control your bot and read what it sends. `.gitignore` excludes `.env`, but the token never made it into `.env`. | Security |
| 2 | `run.py`, `src/dashboard/routes.py` | **Dashboard has no authentication, binds to `0.0.0.0`, and exposes state-changing `POST /start`, `/stop`, `/restart` with no CSRF protection.** Anyone on the same Wi-Fi can control the system. | Security |
| 3 | `src/face/database.py` | **`pickle.loads()` on database contents.** If the DB file is ever swapped or tampered with, loading it executes arbitrary code. Embeddings are just 512 floats; store raw bytes instead. | Security |
| 4 | `src/motion/snapshot.py`, `src/face/*` | **Biometric data (face embeddings) and snapshots stored unencrypted, with no consent record, retention limit, or delete-everything path.** Face data is a special category under GDPR and regulated by other laws (see `SECURITY_AND_PRIVACY.md`). | Privacy / Legal |
| 5 | `src/face/face_detector.py`, `src/ai/detector.py` | **Licensing blockers.** InsightFace `buffalo_l` weights are non-commercial research only. Ultralytics YOLOv8 is AGPL-3.0 (commercial/closed-source use needs an Enterprise License). ✔ checked against upstream license statements via web search on 2026-10-29; re-read the license files yourself before you ship. | Legal / Business |
| 6 | `src/database/migration.py` | **File does not compile.** The `faces` table SQL sits outside any string (`SyntaxError`). ✔ verified. Also `initializer.py` imports `src.database.migrations` (plural), which doesn't exist; `schema.py` is a third, partial copy. **The database can never be initialised.** | Correctness |
| 7 | `src/events/event_bus.py`, `src/notifications/notifier.py`, `src/main.py` | **One failed Telegram call stops detection.** `EventBus.publish` calls subscribers with no `try/except`. `requests.post` raises on timeout/no internet → exception escapes → `run()` logs "Sentinel Engine crashed" and the loop ends. Notification is also synchronous, so a slow network **freezes video processing** for up to 10 s per alert. | Reliability |

## 🟠 High Priority

| # | File | Issue | Category |
|---|------|-------|----------|
| 8 | `src/database/repository.py` | `save()` calls `event.timestamp.isoformat()`, but `Event.timestamp` is already a `str`. ✔ verified `AttributeError`. More importantly, **nothing ever calls `save()`**. Events, detections, and snapshots are never persisted, so the whole `investigation/` package reads empty tables. | Correctness |
| 9 | `src/dashboard/routes.py`, `api.py`, `app.js`, `index.html` | **Dashboard shows fake data.** `DashboardService` is instantiated twice (routes + api), the engine never updates either, and the `api` blueprint is never registered. CPU/RAM/FPS/Telegram status are static zeros. `app.js` reads `state.last_event` from `/api/status`, which doesn't return that field, so the "Last Event" box displays the text `undefined` every second. Two separate JS pollers hit the same endpoint. | Correctness / UX |
| 10 | `src/main.py` | `cv2.imshow` runs inside the engine **thread** (breaks on macOS, fails on headless servers/Docker). `engine = SentinelEngine()` runs at **import time**, loading YOLO + InsightFace + Telegram client as a side effect of `import src.main`. | Architecture |
| 11 | `src/camera/usb_camera.py`, `src/main.py` | A single dropped frame raises `CameraCaptureError`, which kills the engine. No reconnect, no backoff, no health state. The `if frame is None` check is dead code (capture never returns `None`). | Reliability |
| 12 | `src/main.py`, `src/face/*` | Face pipeline runs **once per detected person** (3 people → 3 identical face passes and 3 duplicate events). `FaceManager` builds `FaceDetector` twice (also inside `FaceRegistry`), so the 300 MB model loads twice. `FaceMatcher.match` re-reads and un-pickles **every stored face from SQLite for every face on every frame.** Matcher threshold is 0.50 while the dashboard settings say 0.60. | Performance / Correctness |
| 13 | `src/face/*` | **No liveness / anti-spoofing.** A printed photo or a phone screen will be "recognised". Fine for "who's at the door" alerts; unacceptable if marketed as access control. Must be disclosed. | Security / Product |
| 14 | `src/face/database.py`, `face_repository.py`, `database/manager.py` | **Two databases and two face stores:** `sentinel.db` in the current directory (pickle, table `known_faces`) vs `data/database/sentinel.db` (events). `FaceRepository` (JSON, table `faces`) is a third, unused implementation. SQLite connections are created in one thread and used in another (`check_same_thread` default). The default DB directory `data/database/` is never created. | Architecture |

## 🟡 Suggestions

| # | File | Suggestion | Category |
|---|------|------------|----------|
| 15 | `tools/fix_imports.py`, `*.bak` | The import-rewriter uses `ast.unparse`, which **deletes all comments and reformats code** (visible in your test files). Don't rewrite imports. Make the project a proper package (`pyproject.toml` + `pip install -e .`). Delete all `.bak` files from the repo. | Maintainability |
| 16 | `src/test_*.py` | These are scripts, not tests (no assertions) and `test_face_database.py` writes into the real DB. Move to `tests/`, use `pytest`, use temp DBs and a video-file fixture. | Testing |
| 17 | `src/engine/*`, `face_service.py`, `face_registration.py`, `websocket.py`, `database/models.py`, `sqlite.py`, `notification_manager.py`, `config/default.py`, `ai/labels.py`, `ai/model_loader.py` | ~15 **empty stub files** from an earlier plan. Delete or implement. They make the project look more finished than it is. | Maintainability |
| 18 | `src/ai/detection_result.py`, `ai_interface.py`, `investigation/event_repository.py` | Missing imports (`dataclass`, `ABC`) and one file is pseudo-code (bare function names). Each would raise on import; they only survive because nothing imports them. | Correctness |
| 19 | `src/ai/detector.py`, `routes.py` | Debug `print`s at import time and in request handlers. Use the logger. | Maintainability |
| 20 | `src/camera/mock_camera.py` | Returns the string `"Mock Frame"` as `data`; `MotionDetector` would crash on it. Make it return synthetic or video-file frames. This is your key to testing without a webcam. | Testing |
| 21 | `src/motion/snapshot.py` | Filename resolution is 1 second (collisions overwrite), a snapshot is written on **every** motion frame, no retention limit (disk fills), relative path depends on the working directory, and the `snapshots` table/FK is never used. | Reliability |
| 22 | `src/notifications/notifier.py` | Cooldown is per event *type*, so the second unknown person within 30 s is silently dropped. `notify_photo` exists but is never called, so alerts carry no image. | Product |
| 23 | `src/face/embedding.py` | `embedding /= norm` mutates the InsightFace object's array in place; `similarity()` divides by `np.linalg.norm` with no zero guard. | Correctness |
| 24 | `src/camera/frame.py` | `datetime.utcnow` is deprecated (Python 3.12+); use `datetime.now(timezone.utc)`. | Maintainability |
| 25 | repo root | No `requirements.txt`/`pyproject.toml` in the upload (if you have one, pin versions). No `.env.example`, no CI, no linter (`ruff`), no type check. `.gitignore` is missing `snapshots/`, `*.db`, `*.bak`, `*.pt`, `data/`. A stray `git add .` could commit face data. | DevOps |
| 26 | `src/camera/camera_types.py` | Enum already lists RTSP/IP/Android but only USB and Mock exist. This is the seed of your multi-camera feature (see `ARCHITECTURE.md`). | Product |

---

## ✅ What Looks Good

- **Clean layering intent.** `CameraInterface` (ABC) → `CameraManager`, `EventBus` → `EventManager`, repositories, a `Frame` dataclass. This is the right shape for plug-in cameras and notification channels.
- **Event-driven design.** Detectors publish events; notifiers subscribe. This is exactly how to add in-app, email, and webhook channels without touching detection code.
- **Sensible tech picks for a prototype.** InsightFace/ArcFace embeddings with cosine similarity, a motion gate before the expensive YOLO call, and normalised embeddings are all correct ideas.
- **Config loader with `dotenv`** and a frozen `Settings` dataclass. Just wire the Telegram token through it.
- **Cooldown manager**, graceful `stop()`, `daemon` engine thread, and structured logging. Good instincts.
- **`dataclass(slots=True)`** on value objects, type hints on most signatures.
- You identified UI/UX, security, and scalability as weak spots yourself. That's the hardest part of a review.

---

## Fix Recipes for the Top Issues

### 1. Secrets (Issue 1). Do this **today**

1. Open Telegram → **@BotFather** → `/revoke` → choose your bot → it issues a new token. The old one stops working immediately. *This is the real fix.*
2. Put the new token in `.env` (never committed):
   ```
   TELEGRAM_BOT_TOKEN=<new token>
   TELEGRAM_CHAT_ID=<your id>
   ```
3. Load it from config:
   ```python
   # src/notifications/settings.py
   import os
   BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]   # crash loudly if missing
   CHAT_ID = int(os.environ["TELEGRAM_CHAT_ID"])
   ```
4. Delete `telegram_test.py`'s hardcoded values the same way.
5. Deleting the file in a new commit does **not** remove it from git history. If the repo was ever public, assume the old token is burned (step 1 covers that). To clean history for tidiness: `git filter-repo --replace-text replacements.txt`, then force-push.

### 2. Embeddings without `pickle` (Issue 3)

```python
import numpy as np

def to_blob(vec) -> bytes:
    return np.asarray(vec, dtype=np.float32).tobytes()

def from_blob(blob: bytes) -> np.ndarray:
    return np.frombuffer(blob, dtype=np.float32).copy()
```
Re-register your test faces afterwards. You're re-enrolling anyway when you change models (see ADR-004).

### 3. Make one failing subscriber unable to stop the engine (Issue 7)

```python
# src/events/event_bus.py
import logging
logger = logging.getLogger(__name__)

def publish(self, event):
    for callback in [*self._subscribers.get(event.event_type, []),
                     *self._subscribers.get("*", [])]:
        try:
            callback(event)
        except Exception:
            logger.exception("Subscriber %r failed on %s", callback, event.event_type)
```
This is the 5-minute fix. The proper fix is an outbox + background worker (see `ARCHITECTURE.md` §Notifications).

### 4. Database that actually initialises (Issues 6, 8, 14)

- Delete `schema.py` and `initializer.py`. Keep **one** schema module.
- Wrap the faces SQL in `CREATE_FACES_TABLE = """ ... """`.
- `os.makedirs(Path(settings.database_path).parent, exist_ok=True)` before `sqlite3.connect`.
- Call `initialize_database()` once at startup, then have the engine subscribe `EventRepository.save` to the `"*"` event type.
- `event.timestamp` is already ISO text → store it directly.
- Longer term: SQLAlchemy + Alembic (ADR-003).

### 5. Run face recognition once per frame (Issue 12)

```python
persons = [d for d in detections if d.label == "person"]
if persons:
    self.events.publish(event_types.PERSON_DETECTED, "ai",
                        f"{len(persons)} person(s) detected.")
    for result in self.face_manager.process(frame):      # once, not per person
        ...
```
And cache embeddings in memory:

```python
class FaceIndex:
    """All known embeddings in one matrix; matching = one matrix multiply."""
    def __init__(self):
        self.names: list[str] = []
        self.matrix = np.empty((0, 512), dtype=np.float32)

    def load(self, rows):                       # rows: [(name, vec), ...]
        self.names = [n for n, _ in rows]
        self.matrix = np.stack([v / np.linalg.norm(v) for _, v in rows]) if rows else self.matrix

    def best(self, query):
        if not self.names:
            return "Unknown", -1.0
        scores = self.matrix @ (query / np.linalg.norm(query))
        i = int(scores.argmax())
        return self.names[i], float(scores[i])
```
Reload the index only when someone enrolls or deletes a face. This stays fast into the tens of thousands of embeddings.

### 6. Remove `cv2.imshow` from the engine

Delete it (and `waitKey`). Serve the live view in the dashboard as an MJPEG stream instead, so it works in Docker, on servers, and in a browser on a phone. Keep `imshow` only behind a `--debug-window` flag in a script run from the main thread.

---

## Suggested Review Order for the Rebuild

1. Secrets → `.env` → revoke token (today)
2. Package setup + delete dead files + CI lint (Phase 0)
3. DB + persistence (Phase 0–1)
4. Auth + CSRF + bind to localhost (Phase 1)
5. Camera reliability (Phase 1)
6. Model swap + multi-face + index (Phase 2)
7. Notification outbox (Phase 3)
