# Deploy Checklist: Project Sentinel

Sentinel is **self-hosted software**, so "deploying" means *shipping a release that customers install and upgrade themselves*. You can't hot-fix their machines, so the checklist front-loads testing and makes rollback a first-class feature.

Copy the relevant section into a GitHub issue for every release. **Run it even for tiny patches.**

**Release:** `vX.Y.Z` | **Date:** ____ | **Releaser:** ____ | **Type:** ☐ Patch ☐ Minor ☐ Major (☐ includes DB migration)

---

## A. Gate: first public / paid release only (one-time)

**Legal & licensing**
- [ ] No non-commercial or AGPL components shipped (ADR-004 resolved); `THIRD_PARTY_LICENSES.md` generated and bundled
- [ ] Model weight licences read and recorded (not just code licences)
- [ ] EULA, privacy policy, refund policy published and linked from installer + website
- [ ] Product name/trademark searched; domain registered
- [ ] Lawyer/accountant review done for each target market; payment account verified for payouts

**Security (see `SECURITY_AND_PRIVACY.md` §2, all boxes)**
- [ ] No secrets in repo or git history (`gitleaks detect`); previous Telegram token **revoked**
- [ ] Auth, CSRF, localhost-by-default verified manually *and* by tests
- [ ] `pip-audit` and `bandit` clean of high/critical
- [ ] Licence signing private key stored offline; public key embedded; key-issue script tested

**Product**
- [ ] Clean-machine install tested on every supported OS (fresh VM, no dev tools)
- [ ] Setup wizard → first real alert in under 15 minutes (timed by someone who isn't you)
- [ ] Tested with ≥ 3 camera types (USB, phone app, RTSP IP camera)
- [ ] "Supported hardware" table published from real benchmark numbers
- [ ] Support email, docs site, and community space live

---

## B. Pre-Deploy (every release)

- [ ] All tests passing in CI (unit + integration with `sample.mp4` fake camera)
- [ ] `ruff` and type checks clean
- [ ] Code reviewed (self-review against `CODE_REVIEW.md` categories if solo; ideally a second pair of eyes for auth/migrations)
- [ ] No known critical bugs in the milestone
- [ ] **Version bumped** (single source of truth) and `CHANGELOG.md` updated (Keep-a-Changelog format)
- [ ] **Database migrations tested** (if applicable):
  - [ ] Upgrade from the **previous release's DB** *and* from a DB with realistic data volume (10k+ events, 100 people)
  - [ ] Automatic backup of DB file happens *before* migration
  - [ ] Failed migration leaves the original DB untouched and shows a clear error
  - [ ] Downgrade/restore procedure documented
- [ ] New settings have safe defaults; old config files still load
- [ ] Feature flags/`beta` toggles default **off** for unfinished features
- [ ] Rollback plan written (previous installer/image kept available; restore steps)
- [ ] Dependency versions pinned; image/installer size sanity-checked

## C. Build

- [ ] Reproducible build from a tagged commit in CI (not from your laptop)
- [ ] Docker image built, tagged `X.Y.Z` and `latest`; runs as **non-root**; healthcheck passes
- [ ] Windows installer built; **code-signed** if certificate available; antivirus false-positive check on a clean VM
- [ ] SHA-256 checksums generated and published
- [ ] Licence verification works with a valid, expired, tampered, and missing key

## D. Staging / Beta Verification

- [ ] Install on a clean VM/PC → complete setup wizard
- [ ] Add a camera: USB, RTSP (with wrong password → clear error; with right password → live preview)
- [ ] Unplug/reboot the camera → tile shows reconnecting, then recovers without restart
- [ ] Pull the network cable → detection continues; notifications queue and deliver after reconnect
- [ ] Enrol a person with 3 photos → recognised on live feed; stranger flagged Unknown; unknown inbox → promote works
- [ ] Each notification channel: **Send test** works; real alert arrives with snapshot; quiet hours/cooldown respected
- [ ] Reboot the machine → service/container restarts and resumes automatically
- [ ] Run for **24 hours** with 2+ cameras: memory flat, CPU within target, disk growth matches retention
- [ ] Upgrade from the previous version with existing data → everything intact
- [ ] Delete a person → embeddings/photos gone; "delete all data" works
- [ ] Browser check: Chrome, Firefox, Safari, mobile Safari/Chrome; dark mode; keyboard navigation
- [ ] Run smoke tests: `/api/health` OK, login/logout, one event appears in timeline

## E. Release

- [ ] Publish to beta channel / small cohort first (5–10 users) → wait ≥ 48 h
- [ ] Tag release; upload artifacts + checksums; publish release notes (what changed, known issues, upgrade notes)
- [ ] Update download links on the website; update docs for changed behaviour
- [ ] Promote to stable channel if beta metrics are clean

## F. Post-Release (first 48 h)

- [ ] Monitor support inbox/community for install and upgrade issues
- [ ] Review any opt-in crash reports/diagnostics bundles received
- [ ] Confirm metrics: install-success reports, crash-free sessions, support tickets per customer
- [ ] Close milestone issues; start next milestone; note what the checklist missed and **add it here**

---

## Rollback Triggers (decide *before* releasing)

Pull the release from the download page and point users to the previous version if **any** occur within 72 h:

- ≥ 2 independent reports of **data loss or failed migration**
- Crash-free sessions in the beta cohort **< 98%**
- Install/upgrade success rate **< 90%** in reports
- Any **security vulnerability** exploitable without authentication
- Alerts not delivered on the default channel for a majority of testers
- Face recognition accuracy regression > agreed tolerance on the benchmark set

**Rollback steps**
1. Remove the bad version from the download page; restore the previous installer/image as `latest`.
2. Publish a short notice with exact steps: stop service → restore the pre-migration DB backup → install the previous version.
3. Patch, re-run this checklist, ship a new patch version (never re-use a version number).
4. Write a short post-mortem: what happened, why testing missed it, what's added to this checklist.

---

## Quick Rollout Cadence for the Solo Developer
- **Patch** (bug fix): checklist sections B, C, D (shortened), E.
- **Minor** (features): all sections except A.
- **Major / migration-heavy:** everything, plus a longer beta (2 weeks).
