# Architecture: Project Sentinel (MVP → v1)

> Companion docs: [DECISIONS.md](DECISIONS.md) (why each choice), [SECURITY_AND_PRIVACY.md](SECURITY_AND_PRIVACY.md), [../ROADMAP.md](../ROADMAP.md)

---

## 1. Requirements

### Functional (MVP)
1. Connect **any** camera: USB webcam, RTSP/IP camera, phone-as-camera, video file (for demos/tests).
2. Run several cameras at once.
3. Detect motion → detect people/objects → recognise **known people** (many faces) → flag **unknown** visitors.
4. Enrol people easily: upload photos or capture from a camera; review unknown faces and promote them to people with one click.
5. Alert the owner through **Sentinel's own notification system**: in-app live alerts, browser/phone push, email, webhook. Telegram becomes an optional bring-your-own-bot channel.
6. Web dashboard with login: live view, event timeline with snapshots, people, cameras, notification rules, settings.
7. Installable by a non-developer in under 15 minutes.

### Non-functional
| Area | Target (to be measured, not assumed) |
|------|--------------------------------------|
| Hardware | Runs on a modern mini-PC / laptop CPU without a GPU |
| Scale | 1–8 cameras, 1–500 known people per install |
| Latency | Person at camera → alert on phone in under ~5 s (CPU-only) |
| Reliability | Survives camera drops, network loss, reboot (auto-restart, auto-reconnect) |
| Privacy | Video and face data never leave the customer's machine by default |
| Security | No default passwords, localhost-only until the owner opts in to LAN access |
| Maintainability | One developer can understand and change any module in an afternoon |

### Constraints
- Solo developer, learning as you go → **boring, well-documented technology**, Python end to end.
- Must be sellable → permissive licences only (see `BUSINESS_AND_LICENSING.md`).
- No GPU assumption, no cloud bill per customer.

---

## 2. Product model: local-first

Sentinel runs **on the customer's hardware** (PC, mini-PC, NAS, or a Docker host). Video never touches your servers.

Why: streaming video to a cloud for processing costs real money per camera per month, and storing customers' faces makes *you* a regulated biometric-data processor. Local-first sidesteps both and is also the strongest privacy selling point. Remote access and cloud push can later become a paid add-on (ADR-001).

---

## 3. High-level design

```
 ┌──────────────┐
 │   Cameras    │  USB · RTSP/IP · phone app stream · video file
 └──────┬───────┘
        │ frames
 ┌──────▼────────────────────────────────────────────────────┐
 │  CAMERA LAYER  (one CameraWorker thread per camera)       │
 │  reader thread → "latest frame" slot (old frames dropped) │
 │  auto-reconnect + backoff · health state · MJPEG preview  │
 └──────┬────────────────────────────────────────────────────┘
        │ latest frame @ detection_fps (e.g. 3–5 fps)
 ┌──────▼────────────────────────────────────────────────────┐
 │  PIPELINE  (shared inference worker, bounded queue)       │
 │  1. motion gate  (cheap)                                  │
 │  2. person/object detector (permissive-licensed model)    │
 │  3. face detect on person crop → embedding                │
 │  4. FaceIndex.match → known / unknown                     │
 └──────┬────────────────────────────────────────────────────┘
        │ domain events (PERSON_SEEN, UNKNOWN_FACE, …)
 ┌──────▼──────┐
 │  EVENT BUS  │  subscribers are isolated: one failure never stops others
 └──┬───────┬──┘
    │       │
    │       └────────────────────────────┐
 ┌──▼───────────────┐          ┌─────────▼──────────────────────┐
 │  EVENT STORE     │          │  NOTIFICATION SERVICE          │
 │  SQLite (WAL)    │          │  rules → outbox → workers      │
 │  + snapshot files│          │  in-app (SSE) · Web Push ·     │
 └──┬───────────────┘          │  email · webhook · Telegram(BYO)│
    │                          └────────────────────────────────┘
 ┌──▼──────────────────────────────────────────────┐
 │  WEB APP  (FastAPI + Jinja2/HTMX)               │
 │  auth · REST/JSON API · SSE live stream · UI    │
 └─────────────────────────────────────────────────┘
```

Everything runs in **one Python process** for the MVP (threads for I/O, native libs release the GIL during heavy work). Split into processes later only if measurements demand it.

---

## 4. Component design

### 4.1 Camera layer: "connect any camera"

**Key insight:** almost every camera type reduces to *"a URL or index that OpenCV/FFmpeg can read"*. You don't need a different class for every brand.

| Source type | What the user enters | How it's read |
|-------------|----------------------|---------------|
| USB / built-in webcam | Device index (0, 1…) | `cv2.VideoCapture(index)` |
| RTSP / IP camera (Hikvision, Dahua, Reolink, TP-Link Tapo, Amcrest…) | `rtsp://user:pass@192.168.1.20:554/stream1` | `cv2.VideoCapture(url, cv2.CAP_FFMPEG)` |
| HTTP/MJPEG camera, old IP cams | `http://…/video` | same |
| Phone as camera (apps like IP Webcam, DroidCam, Alfred) | URL the app shows | same |
| Video file (demo/testing) | file path | same, with loop |
| *(later)* ONVIF auto-discovery | click "Scan network" | WS-Discovery → ONVIF → fetch RTSP URL |
| *(later)* Browser/phone camera via WebRTC | open a link on the phone | `aiortc` |

**Classes (evolves your existing `CameraInterface`):**

```python
class CameraSource(ABC):                 # your CameraInterface, renamed
    def open(self) -> None: ...
    def read(self) -> Frame: ...         # raises CameraReadError
    def close(self) -> None: ...

class OpenCVSource(CameraSource): ...    # USB + RTSP + HTTP + file, one class

class CameraWorker(threading.Thread):
    """Owns one source. Keeps only the newest frame. Reconnects forever."""
    # state: CONNECTING | ONLINE | RECONNECTING | ERROR(message)
```

**Four reliability rules that RTSP will force on you:**
1. **Reader thread + "latest frame" slot.** RTSP buffers frames; if you process slowly you lag further behind real time. Always read continuously and process only the newest frame.
2. **Reconnect with exponential backoff** (1 s → 2 → 4 … cap 30 s). Cameras reboot, Wi-Fi drops.
3. **Use the camera's sub-stream for detection** (typically 640×360) and the main stream only for snapshots. This is the single biggest CPU saver; each camera usually exposes both.
4. **Never log the full URL.** It contains the camera password. Mask it (`rtsp://user:***@host/…`).

**"Add camera" UX (important for non-technical buyers):** type picker → paste URL or pick USB device → **[Test connection]** grabs one frame and shows it → name + save. Common brands get a URL-template helper ("Reolink: `rtsp://USER:PASS@IP:554/h264Preview_01_sub`"). Templates are data, not code.

### 4.2 Pipeline and scheduling

- Each camera produces a frame at `detection_fps` (default 3). Don't run AI at the camera's 25–30 fps.
- **Motion gate first** (your existing `MotionDetector`, per-camera instance; it currently has global state, which is fine, as long as each camera gets its own).
- Then **person detection**; then **face detection on the person crop only** (faster and more accurate than whole-frame).
- One shared **inference worker** with a bounded queue (size ≈ 2 × cameras). If it is full, drop the oldest frame. Under load the system degrades to a lower FPS instead of exploding memory.
- Ignore the same person re-triggering: **per-camera, per-identity cooldown** (e.g. "Aryan seen at Front Door" at most once per 60 s), separate from notification cooldown.

### 4.3 Face recognition: "multiple faces"

Your current schema (`name PRIMARY KEY`, one embedding) means one photo per person, replaced on re-register. Real-world fix:

```
people            1 ──── N   face_embeddings
(id, name, notes,            (id, person_id, vector BLOB float32,
 consent_at)                  model_id, quality, created_at, source_photo?)
```

- **3–5 photos per person** (different angles/lighting) → far fewer false "Unknown"s.
- **Enrolment quality gate:** exactly one face, detector confidence ≥ 0.7, face ≥ ~80 px wide, not blurry (variance of Laplacian), otherwise tell the user *why* it was rejected.
- **Matching:** all embeddings in one in-memory matrix (`FaceIndex`, see Code Review recipe 5). Score = best cosine similarity per person. Accept if `score ≥ threshold` **and** the margin to the second-best person is large enough.
- **`model_id` on every embedding:** vectors from different models are not comparable. If you swap models you must re-enrol (keep original photos, with consent, to automate this).
- **Unknown-face inbox:** save a crop + embedding of each unknown face (deduplicated by similarity). UI: "Who is this?" → *Name them* (promotes to a person) or *Dismiss*. This is the highest-value UX feature in the whole product.
- Thresholds are **per-install settings with a sane default**; expose a "strict / balanced / lenient" slider, not raw cosine numbers.
- **Honesty about limits:** no liveness detection. Photos and screens can fool it. Say so in the docs and don't market it as door-lock security.

### 4.4 Notifications: "our own system, not Telegram"

First, an honest note: a phone can only get a lock-screen alert when something talks to Apple (APNs) or Google (FCM). That is true for *every* product, including Ring. "Our own system" therefore means **you own the logic, the rules, the channels, and the inbox**, and use standard push transports only where unavoidable, with encrypted payloads.

**Design = channels (plugins) + rules + outbox:**

```
Event ──► Rule engine ──► Outbox (DB table) ──► Worker pool ──► Channel.send()
          "unknown person        status: pending/sent/failed         InApp (SSE)
           at Front Door,        attempts, next_attempt_at           WebPush
           22:00–06:00,                                              Email (SMTP)
           cooldown 120 s"                                           Webhook
                                                                     Telegram (BYO token)
```

```python
class NotificationChannel(ABC):
    type: str
    def send(self, notification: Notification) -> None: ...   # raise to trigger retry
```

| Channel | What it gives | Cost to you | MVP? |
|---------|---------------|-------------|------|
| **In-app** (Server-Sent Events + notification centre + sound) | Instant alerts when the dashboard is open | none | ✅ |
| **Web Push / installable PWA** (VAPID keys you generate) | Phone/desktop alerts, no app-store account | none (browser vendors relay it; payload is end-to-end encrypted) | ✅ |
| **Email (SMTP)** | Daily summary + critical alerts; customer enters their own SMTP | none | ✅ |
| **Webhook** | Lets technical users wire Home Assistant, Slack, Discord, n8n, Telegram | none | ✅ |
| **Telegram** | Existing users' habit; **customer supplies their own bot token** | none | ✅ (optional) |
| Native mobile app (FCM/APNs) | Best UX | large dev cost + store accounts | ❌ post-MVP |
| SMS | Reaches anyone | per-message fee | ❌ post-MVP |
| Cloud relay (remote access + push when away) | Works outside home Wi-Fi | your server cost → **paid subscription** | ❌ post-MVP |

**Why an outbox:** it fixes your #1 reliability bug. Detection only writes a row (fast, can't fail on network); workers deliver, retry with backoff, and record failures visibly in the UI ("Email failed: SMTP auth error"). Cooldown and quiet hours live in the rule engine, per (rule, camera, person), instead of per event type.

**Rules (MVP):** trigger (`unknown_person` / `known_person` / `person` / `motion`), cameras, time window, channels, cooldown, "attach snapshot" toggle. Ship 3 default rules so a new install is useful instantly.

### 4.5 Web app, auth, and UI/UX

- **FastAPI** + Jinja2 templates + **HTMX** (partial page updates without a JS framework) + Alpine.js for small interactions + Tailwind CSS. SSE for live events. (ADR-002, ADR-007.)
- **Auth:** first-run **setup wizard** creates the admin account (no default password), argon2/bcrypt hashes, session cookie (`HttpOnly`, `SameSite=Lax`, `Secure` when on HTTPS), CSRF token on all forms, login rate-limit. Roles: `admin`, `viewer` (viewer can't change settings or see face management).
- **Default bind `127.0.0.1`.** LAN access is an explicit toggle that shows a warning and recommends HTTPS.
- **UI/UX principles for the redesign:**
  1. *First run is a wizard:* create admin → add a camera (with test) → add yourself as a person → set up a notification channel → send test alert. The user should see their first real alert within minutes.
  2. *The dashboard answers "is everything OK?"* at a glance (camera tiles with green/red status, last event, system health) rather than listing raw numbers.
  3. *Events timeline with thumbnails*, filter by camera/person/type, click for full snapshot.
  4. *Never a blank screen:* empty states tell the user the next step. *Never a silent failure:* every error shows what happened and what to try.
  5. Works on a phone (responsive), dark mode, keyboard-accessible, readable contrast.
  6. No full-page reload for start/stop (HTMX swap + toast confirmation).

### 4.6 Configuration

Two layers: **environment** (`.env`: secrets, paths, bind address, log level) and **database settings** (things the user changes in the UI: thresholds, retention, rules). Use `pydantic-settings` to validate env at startup and fail with a clear message. Secrets for channels/cameras stored encrypted (Fernet) with a key from the environment/OS keyring.

---

## 5. Data model (SQLite, WAL mode)

```
users(id, username, password_hash, role, created_at, last_login_at)
cameras(id, name, kind, source_enc, enabled, detection_fps, created_at)
people(id, name, notes, consent_at, created_at)
face_embeddings(id, person_id→people, model_id, vector BLOB, quality, photo_path?, created_at)
unknown_faces(id, camera_id, seen_at, model_id, vector BLOB, crop_path, status[new|dismissed|promoted])
events(id, ts, camera_id, type, person_id?, confidence, snapshot_path?, meta_json)
notification_channels(id, type, config_enc, enabled)
notification_rules(id, name, trigger_json, channel_ids_json, cooldown_s, quiet_hours_json, attach_snapshot, enabled)
notification_outbox(id, event_id, channel_id, status, attempts, last_error, next_attempt_at, created_at)
settings(key, value_json)
audit_log(id, ts, user_id?, action, detail)
license(key, payload_json, verified_at)
```
Indexes: `events(ts DESC)`, `events(camera_id, ts)`, `events(person_id, ts)`, `outbox(status, next_attempt_at)`.
Use **Alembic migrations from day one**, because every paying customer's database must upgrade in place without data loss.

**Retention:** events/snapshots older than N days (default 30) deleted nightly; "delete everything about this person" is one button.

---

## 6. API sketch (JSON + HTML fragments)

```
POST /setup                          first-run admin creation (only if no users exist)
POST /auth/login · /auth/logout

GET  /api/cameras                    POST /api/cameras      POST /api/cameras/test
PATCH|DELETE /api/cameras/{id}       GET  /api/cameras/{id}/stream.mjpg
GET  /api/people                     POST /api/people       (multipart photos)
POST /api/people/{id}/photos         DELETE /api/people/{id}
GET  /api/unknown-faces              POST /api/unknown-faces/{id}/promote | /dismiss
GET  /api/events?camera=&person=&type=&from=&to=&cursor=
GET  /api/events/stream              (SSE live)
GET|POST /api/notification-channels  POST /api/notification-channels/{id}/test
GET|POST /api/notification-rules
GET  /api/health                     (engine, per-camera status, queue depth, disk)
POST /api/engine/start|stop|restart
```
Paginate everything with cursors; validate with Pydantic; FastAPI generates the OpenAPI docs for free.

---

## 7. Concurrency model

| Thing | Where it runs |
|-------|---------------|
| Web server | asyncio (uvicorn) |
| Each camera reader | 1 thread per camera |
| Inference | 1–2 worker threads (ONNX Runtime releases the GIL) |
| Notification workers | small thread pool |
| DB | SQLite WAL, one short-lived connection per operation / per thread (never share a connection across threads) |
| Engine lifecycle | created in FastAPI `lifespan`, **not** at import |

If a profile shows the GIL is the bottleneck, move inference to a `multiprocessing` worker. The bounded queue boundary already makes that a small change.

---

## 8. Capacity planning (measure, don't guess)

Build a `scripts/benchmark.py` in Phase 2 that reports, on *your* test machine: decode cost per camera, motion-gate time, detector ms/frame, face detect+embed ms/face, match time. Then compute:

```
max_cameras ≈ cpu_budget / (decode + detection_fps × (motion + detector + face))
```
Publish a "tested hardware" table in the docs (e.g. "Intel N100 mini-PC: 4 cameras @ 3 fps"). Customers buy confidence, and support tickets drop when the limits are written down. Later accelerators: OpenVINO (Intel), CUDA, Coral/Hailo.

---

## 9. Error handling and resiliency

| Failure | Behaviour |
|---------|-----------|
| Camera offline / bad frame | Worker → `RECONNECTING`, backoff, UI tile turns red, optional "camera offline" notification after N minutes |
| Model fails to load | Engine refuses to start with a clear UI error; web app stays up |
| Notification channel down | Outbox retries (1 m, 5 m, 30 m…), failure shown in UI, other channels unaffected |
| Disk nearly full | Retention sweeper runs early; warning banner; stop saving snapshots below a free-space floor |
| Process crash / reboot | Service manager restarts it (systemd / Docker `restart: unless-stopped` / Windows service); engine resumes from DB config |
| DB migration fails | Auto-backup of the DB file before every migration; refuse to start and tell the user |

## 10. Observability

Structured logs (JSON optional) with rotation; secrets redacted. `/api/health` plus a **System** page: camera states, FPS per stage, queue depth, outbox backlog, disk usage, model versions, app version. A **"Download diagnostics"** button bundles logs + health (with secrets stripped) so customers can email you something useful. This one feature will save you hours of support.

---

## 11. Target repository layout

```
sentinel/
├─ pyproject.toml            # deps pinned, ruff + pytest config
├─ .env.example
├─ src/sentinel/
│  ├─ app.py                 # FastAPI app factory + lifespan
│  ├─ settings.py            # pydantic-settings
│  ├─ web/                   # routers, templates, static
│  ├─ auth/
│  ├─ cameras/               # sources, worker, registry, url templates
│  ├─ pipeline/              # motion, detector, scheduler
│  ├─ faces/                 # detector, embedder, index, enrolment, unknown inbox
│  ├─ events/                # event types, bus, store
│  ├─ notifications/         # channels/, rules.py, outbox.py, worker.py
│  ├─ licensing/
│  └─ db/                    # models, session, alembic/
├─ tests/                    # pytest; sample.mp4 fixture; fake camera
├─ scripts/                  # benchmark.py, seed_demo.py
├─ docs/
└─ docker/
```
Your current `src/<package>` folders map across almost 1:1. See `PROJECT_SOURCE.md` for the file-by-file disposition.

---

## 12. What I'd revisit as it grows

- **Multi-site / remote access:** cloud relay, WireGuard, or Tailscale integration; account system; Postgres.
- **Recording and clips:** this MVP stores *snapshots*, not continuous video. Event clips (pre/post-roll via a ring buffer, or stream-copy with FFmpeg) are the natural next feature. Full 24/7 NVR is a different, crowded product.
- **Dedicated stream service (go2rtc / FFmpeg subprocess)** if OpenCV's RTSP handling becomes the CPU/latency bottleneck (ADR-006).
- **Person re-identification across cameras**, liveness detection, vehicle/licence-plate recognition.
- **Native mobile app** once push-notification demand justifies the cost.
- **Plugin system** for third-party channels and detectors.
