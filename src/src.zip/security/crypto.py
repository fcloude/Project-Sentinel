"""Encryption of secrets at rest (camera URLs, channel credentials) with Fernet (AES-128-CBC + HMAC).

Two key forms are accepted:

  * ``SecretBox(["<fernet key>", "<old fernet key>"])`` -- the configured form. The first key
    encrypts, the remaining ones only decrypt, so keys can be rotated without downtime.
  * ``SecretBox("<passphrase>")`` -- the legacy form. The passphrase is stretched with HKDF
    first, exactly as the pre-rotation code did, so databases written by older builds keep
    working. New secrets should always use explicit keys from ``SENTINEL_ENCRYPTION_KEYS``.
"""
from __future__ import annotations

import base64
import os
from collections.abc import Iterable

from cryptography.fernet import Fernet, InvalidToken, MultiFernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

_LEGACY_INFO = b"sentinel-secretbox-v1"


def get_encryption_keys() -> tuple[str, ...]:
    """Configured keys: the first one encrypts, the rest only decrypt (rotation)."""
    raw = os.getenv("SENTINEL_ENCRYPTION_KEYS", "")
    keys = tuple(k.strip() for k in raw.split(",") if k.strip())
    if not keys:
        raise RuntimeError("SENTINEL_ENCRYPTION_KEYS is not configured; cannot read stored secrets.")
    return keys


class SecretDecryptionError(Exception):
    """Ciphertext is corrupted/tampered or encrypted with an unknown key."""


def _legacy_fernet_key(passphrase: str) -> str:
    raw = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=_LEGACY_INFO,
    ).derive(passphrase.encode("utf-8"))
    return base64.urlsafe_b64encode(raw).decode("ascii")


class SecretBox:
    """keys[0] encrypts; every key can decrypt -> key rotation without downtime.

    Pass a sequence of Fernet keys to use them verbatim; pass a single string to use the
    legacy HKDF-derived key (kept for reading existing installs, not for new secrets).
    """

    def __init__(self, keys: Iterable[str] | str) -> None:
        if isinstance(keys, str):
            key_strings = [_legacy_fernet_key(keys)]
        else:
            key_strings = [k.decode("ascii") if isinstance(k, bytes) else k for k in keys]

        fernets = [Fernet(k.encode("ascii")) for k in key_strings]
        if not fernets:
            raise ValueError("At least one encryption key is required.")
        self._f = MultiFernet(fernets)

    def encrypt(self, plaintext: str) -> str:
        return self._f.encrypt(plaintext.encode("utf-8")).decode("ascii")

    def decrypt(self, token: str) -> str:
        try:
            return self._f.decrypt(token.encode("ascii")).decode("utf-8")
        except (InvalidToken, ValueError, UnicodeError) as exc:
            raise SecretDecryptionError("Unable to decrypt secret.") from exc

    def rotate(self, token: str) -> str:
        """Re-encrypt an existing token with the primary key."""
        try:
            return self._f.rotate(token.encode("ascii")).decode("ascii")
        except (InvalidToken, ValueError) as exc:
            raise SecretDecryptionError("Unable to rotate secret.") from exc

    @staticmethod
    def generate_key() -> str:
        return Fernet.generate_key().decode("ascii")
