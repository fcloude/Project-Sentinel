"""Project Sentinel security layer (config, auth, CSRF, headers, crypto, validation)."""
