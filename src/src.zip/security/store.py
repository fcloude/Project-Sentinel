"""SQLite store for users, roles and the audit log. One short-lived connection per operation
(never share a connection across threads)."""
from __future__ import annotations

import logging
import os
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from src.security.redaction import redact

logger = logging.getLogger(__name__)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'viewer')),
    active INTEGER NOT NULL DEFAULT 1,
    session_epoch INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    last_login_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    user_id INTEGER,
    username TEXT,
    action TEXT NOT NULL,
    ip TEXT,
    detail TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True, slots=True)
class User:
    id: int
    username: str
    password_hash: str
    role: str
    active: bool
    session_epoch: int


def _row_to_user(row: sqlite3.Row | None) -> User | None:
    if row is None:
        return None
    return User(row["id"], row["username"], row["password_hash"], row["role"], bool(row["active"]), row["session_epoch"])


class SecurityStore:
    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = str(path)
        parent = Path(self.path).parent
        parent.mkdir(parents=True, exist_ok=True)
        with self._tx() as conn:
            conn.executescript(_SCHEMA)
        for target, mode in ((parent, 0o700), (Path(self.path), 0o600)):
            try:
                os.chmod(target, mode)  # no-op / ignored on Windows
            except OSError:
                pass

    @contextmanager
    def _tx(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA journal_mode=WAL")
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ------------------------------------------------------------ users
    def count_users(self) -> int:
        with self._tx() as c:
            return c.execute("SELECT COUNT(*) FROM users").fetchone()[0]

    def get_user(self, user_id: int) -> User | None:
        with self._tx() as c:
            return _row_to_user(c.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone())

    def get_user_by_name(self, username: str) -> User | None:
        with self._tx() as c:
            return _row_to_user(c.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone())

    def list_users(self) -> list[User]:
        with self._tx() as c:
            return [_row_to_user(r) for r in c.execute("SELECT * FROM users ORDER BY id")]  # type: ignore[misc]

    def create_first_admin(self, username: str, password_hash: str) -> User | None:
        """Atomic: succeeds only if the users table is empty (two simultaneous setups can't both win)."""
        with self._tx() as c:
            cur = c.execute(
                "INSERT INTO users (username, password_hash, role, created_at) "
                "SELECT ?, ?, 'admin', ? WHERE NOT EXISTS (SELECT 1 FROM users)",
                (username, password_hash, _now()),
            )
            if cur.rowcount != 1:
                return None
        return self.get_user_by_name(username)

    def create_user(self, username: str, password_hash: str, role: str) -> User:
        if role not in ("admin", "viewer"):
            raise ValueError("Invalid role.")
        with self._tx() as c:
            c.execute(
                "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
                (username, password_hash, role, _now()),
            )
        return self.get_user_by_name(username)  # type: ignore[return-value]

    def set_password(self, user_id: int, password_hash: str) -> None:
        """Changes the hash AND invalidates every existing session of that user."""
        with self._tx() as c:
            c.execute(
                "UPDATE users SET password_hash = ?, session_epoch = session_epoch + 1 WHERE id = ?",
                (password_hash, user_id),
            )

    def update_hash(self, user_id: int, password_hash: str) -> None:
        """Transparent re-hash after login (algorithm upgrade). Does NOT invalidate sessions."""
        with self._tx() as c:
            c.execute("UPDATE users SET password_hash = ? WHERE id = ?", (password_hash, user_id))

    def revoke_sessions(self, user_id: int) -> None:
        with self._tx() as c:
            c.execute("UPDATE users SET session_epoch = session_epoch + 1 WHERE id = ?", (user_id,))

    def set_active(self, user_id: int, active: bool) -> None:
        with self._tx() as c:
            c.execute(
                "UPDATE users SET active = ?, session_epoch = session_epoch + 1 WHERE id = ?",
                (1 if active else 0, user_id),
            )

    def delete_user(self, user_id: int) -> None:
        """Remove a user. The audit log keeps their username for accountability."""
        with self._tx() as c:
            c.execute("DELETE FROM users WHERE id = ?", (user_id,))

    def record_login(self, user_id: int) -> None:
        with self._tx() as c:
            c.execute("UPDATE users SET last_login_at = ? WHERE id = ?", (_now(), user_id))

    # ------------------------------------------------------------ audit log
    def audit(self, action: str, *, user_id: int | None = None, username: str | None = None,
              ip: str | None = None, detail: str = "") -> None:
        """Never raises: an audit failure must not break the request. Never put secrets in `detail`."""
        try:
            with self._tx() as c:
                c.execute(
                    "INSERT INTO audit_log (ts, user_id, username, action, ip, detail) VALUES (?, ?, ?, ?, ?, ?)",
                    (_now(), user_id, (username or "")[:64] or None, action[:64], (ip or "")[:64] or None,
                     redact(detail)[:500]),
                )
        except Exception:
            logger.exception("Failed to write audit log entry")

    def recent_audit(self, limit: int = 100) -> list[sqlite3.Row]:
        with self._tx() as c:
            return c.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
