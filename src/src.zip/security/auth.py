"""Authentication, sessions, roles and first-run setup.

Policy is DEFAULT-DENY and enforced in one place (a before_request hook), so a forgotten decorator
on a new route can never expose it:
  * every endpoint requires a logged-in user, except PUBLIC_ENDPOINTS
  * every non-GET/HEAD/OPTIONS request requires the 'admin' role, except SELF_SERVICE_ENDPOINTS
"""
from __future__ import annotations

import hmac
import re
import time

from flask import Blueprint, abort, current_app, g, jsonify, redirect, render_template, request, session, url_for

from src.security import passwords
from src.security.config import SecurityConfig, is_loopback
from src.security.csrf import SAFE_METHODS, SESSION_KEY as CSRF_KEY, get_token
from src.security.ratelimit import LoginThrottle
from src.security.store import SecurityStore, User

bp = Blueprint("auth", __name__)

# Public by design: the login/setup pages, static assets, the liveness probe, and the PWA
# files (a browser must be able to fetch the manifest and service worker before signing in).
PUBLIC_ENDPOINTS = frozenset({
    "auth.login", "auth.setup", "static", "health", "healthz", "manifest", "service_worker",
})
SELF_SERVICE_ENDPOINTS = frozenset({"auth.logout", "auth.change_password"})
_USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


def _store() -> SecurityStore:
    return current_app.extensions["sentinel_store"]


def _config() -> SecurityConfig:
    return current_app.extensions["sentinel_config"]


def _throttle() -> LoginThrottle:
    return current_app.extensions["sentinel_throttle"]


def _ip() -> str:
    return request.remote_addr or "unknown"


def _is_api() -> bool:
    return request.path.startswith("/api/")


def safe_next(target: str | None) -> str:
    """Only same-site relative paths. Blocks //evil.com, /\\evil.com, https://evil.com, javascript:."""
    if not target or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return url_for("index")
    if re.search(r"[\x00-\x1f]", target):
        return url_for("index")
    return target


def init_auth(app, config: SecurityConfig, store: SecurityStore) -> None:
    app.extensions["sentinel_store"] = store
    app.extensions["sentinel_config"] = config
    app.extensions["sentinel_throttle"] = LoginThrottle()
    app.register_blueprint(bp)
    app.before_request(_enforce_access)

    @app.context_processor
    def _inject():
        return {"current_user": g.get("user")}


def _load_session_user() -> User | None:
    uid = session.get("uid")
    issued, seen, epoch = session.get("issued"), session.get("seen"), session.get("epoch")
    if not isinstance(uid, int) or not all(isinstance(v, (int, float)) for v in (issued, seen, epoch)):
        return None
    now, cfg = time.time(), _config()
    if now - issued > cfg.session_absolute_seconds or now - seen > cfg.session_idle_seconds:
        return None
    user = _store().get_user(uid)
    if user is None or not user.active or user.session_epoch != epoch:
        return None  # deleted, disabled, password changed, or "log out everywhere"
    session["seen"] = now
    return user


def _deny_unauthenticated():
    if _is_api():
        return jsonify(error="authentication required"), 401
    return redirect(url_for("auth.login", next=request.full_path.rstrip("?") if request.method == "GET" else None))


def _enforce_access():
    g.user = None
    endpoint = request.endpoint
    if endpoint is None:  # unknown URL / bad method -> normal 404/405
        return None
    if session.get("uid") is not None:
        g.user = _load_session_user()
        if g.user is None:
            session.clear()
    if endpoint in PUBLIC_ENDPOINTS:
        return None
    if g.user is None:
        if not _is_api() and _store().count_users() == 0:
            return redirect(url_for("auth.setup"))
        return _deny_unauthenticated()
    if request.method not in SAFE_METHODS and endpoint not in SELF_SERVICE_ENDPOINTS and g.user.role != "admin":
        _store().audit("forbidden", user_id=g.user.id, username=g.user.username, ip=_ip(),
                       detail=f"{request.method} {request.path}")
        if _is_api():
            return jsonify(error="admin role required"), 403
        abort(403)
    return None


# ------------------------------------------------------------------ views
@bp.route("/login", methods=["GET", "POST"])
def login():
    store = _store()
    if store.count_users() == 0:
        return redirect(url_for("auth.setup"))
    if g.user:
        return redirect(url_for("index"))
    nxt = safe_next(request.values.get("next"))
    if request.method == "GET":
        return render_template("login.html", next=nxt)

    ip = _ip()
    username = (request.form.get("username") or "").strip()[:64]
    password = request.form.get("password") or ""
    throttle = _throttle()
    if throttle.blocked(ip, username):
        store.audit("login_blocked", username=username, ip=ip)
        resp = current_app.make_response(
            (render_template("login.html", next=nxt, error="Too many attempts. Please wait and try again."), 429))
        resp.headers["Retry-After"] = str(max(1, throttle.retry_after(ip, username)))
        return resp

    user = store.get_user_by_name(username)
    valid = user is not None and user.active
    # Always run one hash verification so timing doesn't reveal whether the username exists.
    ok = passwords.verify_password(user.password_hash if valid else passwords.DUMMY_HASH, password) and valid
    if not ok:
        throttle.failure(ip, username)
        store.audit("login_failed", username=username, ip=ip)
        return render_template("login.html", next=nxt, error="Invalid username or password."), 401

    throttle.success(ip, username)
    if passwords.needs_rehash(user.password_hash):
        store.update_hash(user.id, passwords.hash_password(password, enforce_policy=False))
    session.clear()  # new session on privilege change (prevents session fixation)
    session.permanent = True
    now = time.time()
    session.update(uid=user.id, epoch=user.session_epoch, issued=now, seen=now)
    get_token()
    store.record_login(user.id)
    store.audit("login_ok", user_id=user.id, username=user.username, ip=ip)
    return redirect(nxt)


@bp.route("/setup", methods=["GET", "POST"])
def setup():
    """First-run admin creation. Only possible while there are zero users, and only from the machine itself
    (loopback) unless SENTINEL_SETUP_TOKEN is configured and supplied."""
    store, cfg = _store(), _config()
    if store.count_users() > 0:
        abort(404)
    if not cfg.setup_token and not is_loopback(_ip()):
        abort(403)
    if request.method == "GET":
        return render_template("setup.html", needs_token=bool(cfg.setup_token))

    if cfg.setup_token and not hmac.compare_digest(cfg.setup_token, request.form.get("setup_token", "")):
        store.audit("setup_denied", ip=_ip())
        abort(403)
    username = (request.form.get("username") or "").strip()
    password = request.form.get("password") or ""

    def fail(msg: str):
        return render_template("setup.html", needs_token=bool(cfg.setup_token), error=msg), 400

    if not _USERNAME_RE.fullmatch(username):
        return fail("Username must be 3-32 characters: letters, digits, . _ -")
    if password != request.form.get("confirm", ""):
        return fail("Passwords do not match.")
    try:
        pw_hash = passwords.hash_password(password, username=username)
    except passwords.PasswordPolicyError as exc:
        return fail(str(exc))
    user = store.create_first_admin(username, pw_hash)
    if user is None:
        abort(404)  # lost a race with another setup request
    store.audit("setup_admin_created", user_id=user.id, username=user.username, ip=_ip())
    return redirect(url_for("auth.login"))


@bp.route("/logout", methods=["POST"])
def logout():
    user = g.user
    if user:
        _store().audit("logout", user_id=user.id, username=user.username, ip=_ip())
    session.clear()
    return redirect(url_for("auth.login"))


@bp.route("/account/password", methods=["GET", "POST"])
def change_password():
    store, user = _store(), g.user
    if request.method == "GET":
        return render_template("account.html")

    def fail(msg: str):
        return render_template("account.html", error=msg), 400

    if not passwords.verify_password(user.password_hash, request.form.get("current_password", "")):
        store.audit("password_change_failed", user_id=user.id, username=user.username, ip=_ip())
        return fail("Current password is incorrect.")
    new = request.form.get("new_password", "")
    if new != request.form.get("confirm", ""):
        return fail("New passwords do not match.")
    try:
        new_hash = passwords.hash_password(new, username=user.username)
    except passwords.PasswordPolicyError as exc:
        return fail(str(exc))
    store.set_password(user.id, new_hash)  # bumps epoch -> all other sessions die
    session["epoch"] = store.get_user(user.id).session_epoch  # keep THIS session alive
    store.audit("password_changed", user_id=user.id, username=user.username, ip=_ip())
    return render_template("account.html", message="Password changed. Other sessions were signed out.")
