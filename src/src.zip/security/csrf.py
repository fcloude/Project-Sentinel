"""CSRF protection: per-session token (header or form field) + Origin check on state-changing requests.

A rejected login used to surface as a bare ``403 Forbidden``. The token lives in the
session cookie, so the usual causes are a cookie the browser did not send (blocked
cookie, ``Secure`` cookie over plain HTTP, cleared data) or a page rendered before the
session was rotated (log out, password change, restart with a new ``SECRET_KEY``).
Each rejection now records a reason, is written to the audit log and is logged, and the
app can answer the login/setup form with a fresh token instead of a dead end.
"""
from __future__ import annotations

import hmac
import secrets
from urllib.parse import urlparse

from flask import Flask, abort, current_app, g, request, session

SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})
SESSION_KEY = "_csrf"

# Why the request was rejected. Kept short because it is stored in the audit log.
BAD_ORIGIN = "bad_origin"        # Origin header from an untrusted site
NO_SESSION_TOKEN = "no_session"  # the session cookie is missing/expired/blocked
MISSING_TOKEN = "missing_token"  # a session exists but the request carried no token
MISMATCH = "mismatch"            # the token does not belong to this session


def get_token() -> str:
    token = session.get(SESSION_KEY)
    if not token:
        token = session[SESSION_KEY] = secrets.token_urlsafe(32)
    return token


def _origin_allowed(origin: str, trusted: tuple[str, ...]) -> bool:
    if origin == "null":
        return False
    if origin.rstrip("/") in trusted:
        return True
    return urlparse(origin).netloc.lower() == request.host.lower()


def _reject(reason: str) -> None:
    """Record why CSRF validation failed, then refuse the request."""
    g.csrf_failure = reason
    current_app.logger.warning(
        "CSRF rejected (%s) on %s %s", reason, request.method, request.path
    )
    store = current_app.extensions.get("sentinel_store")
    if store is not None:
        user = g.get("user")
        store.audit(
            "csrf_denied",
            user_id=getattr(user, "id", None),
            username=getattr(user, "username", None),
            ip=request.remote_addr,
            detail=f"{reason} {request.method} {request.path}",
        )
    abort(403)


def init_csrf(app: Flask, trusted_origins: tuple[str, ...] = ()) -> None:
    app.jinja_env.globals["csrf_token"] = get_token

    @app.before_request
    def _csrf_protect():
        if request.method in SAFE_METHODS:
            return None
        origin = request.headers.get("Origin")
        if origin and not _origin_allowed(origin, trusted_origins):
            _reject(BAD_ORIGIN)
        expected = session.get(SESSION_KEY)
        supplied = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token") or ""
        if not expected:
            _reject(NO_SESSION_TOKEN)
        if not supplied:
            _reject(MISSING_TOKEN)
        if not hmac.compare_digest(str(expected), str(supplied)):
            _reject(MISMATCH)
        return None
