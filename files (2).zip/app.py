import os

from flask import Flask

from src.dashboard.routes import register_routes


def create_app(engine):
    app = Flask(__name__)

    # SECRET_KEY is required for session cookies and CSRF.
    # Must be set in .env for production — crash loudly if missing in non-debug mode.
    secret = os.environ.get("SECRET_KEY")
    if not secret:
        secret = os.urandom(32)  # shortcut: ephemeral key; sessions lost on restart
        # shortcut: random key on startup, replace with a persistent env var in production
    app.secret_key = secret

    app.config["ENGINE"] = engine

    register_routes(app)

    # Admin Control Center
    from src.admin import admin_bp
    from src.admin.auth import init_admin_db

    init_admin_db()
    app.register_blueprint(admin_bp)

    return app
