"""Admin Control Center routes."""
import sqlite3

from flask import flash, redirect, render_template, request, session, url_for

from src.admin import admin_bp
from src.admin.auth import (
    admin_count,
    audit,
    authenticate,
    create_admin,
    require_admin,
    require_role,
    set_last_login,
    _conn,
)
from src.config.loader import load_settings

settings = load_settings()


# ── Helpers ───────────────────────────────────────────────────────


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    return bool(
        conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)
        ).fetchone()
    )


def _safe_count(conn: sqlite3.Connection, table: str, where: str = "") -> int:
    if not _table_exists(conn, table):
        return 0
    sql = f"SELECT COUNT(*) FROM {table}"
    if where:
        sql += f" WHERE {where}"
    return conn.execute(sql).fetchone()[0]


# ── Setup / Login / Logout ────────────────────────────────────────


@admin_bp.route("/setup", methods=["GET", "POST"])
def setup():
    """First-run: create the super_admin account. Locked out once any admin exists."""
    if admin_count() > 0:
        return redirect(url_for("admin.login"))
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        if len(username) < 3:
            error = "Username must be at least 3 characters."
        elif len(password) < 10:
            error = "Password must be at least 10 characters."
        elif password != confirm:
            error = "Passwords do not match."
        else:
            if create_admin(username, password, role="super_admin"):
                flash("Super admin created. Please log in.", "success")
                return redirect(url_for("admin.login"))
            error = "Username already exists."
    return render_template("admin/setup.html", error=error)


@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    if admin_count() == 0:
        return redirect(url_for("admin.setup"))
    if session.get("admin"):
        return redirect(url_for("admin.dashboard"))
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        admin = authenticate(username, password)
        if admin:
            session["admin"] = admin
            session.permanent = True
            set_last_login(admin["id"])
            audit("LOGIN", ip=request.remote_addr)
            return redirect(url_for("admin.dashboard"))
        # Generic message — don't reveal which field was wrong
        error = "Invalid credentials."
    return render_template("admin/login.html", error=error)


@admin_bp.route("/logout")
def logout():
    if session.get("admin"):
        audit("LOGOUT", ip=request.remote_addr)
    session.pop("admin", None)
    return redirect(url_for("admin.login"))


# ── Dashboard ─────────────────────────────────────────────────────


@admin_bp.route("/")
@require_admin
def dashboard():
    conn = _conn()
    stats = {
        "total_events": _safe_count(conn, "events"),
        "total_detections": _safe_count(conn, "detections"),
        "total_snapshots": _safe_count(conn, "snapshots"),
        "unknown_faces": _safe_count(conn, "detections", "known_person = 0"),
        "known_faces": _safe_count(conn, "known_faces"),
        "admin_users": _safe_count(conn, "admin_users"),
        "audit_entries": _safe_count(conn, "audit_log"),
    }

    recent_events = []
    if _table_exists(conn, "events"):
        recent_events = conn.execute(
            "SELECT event_type, source, message, timestamp "
            "FROM events ORDER BY timestamp DESC LIMIT 10"
        ).fetchall()

    recent_audit = conn.execute(
        "SELECT admin_username, action, detail, created_at "
        "FROM audit_log ORDER BY created_at DESC LIMIT 10"
    ).fetchall()

    # Device summary from detections
    cameras = []
    if _table_exists(conn, "detections"):
        cameras = conn.execute(
            "SELECT camera, COUNT(*) FROM detections GROUP BY camera"
        ).fetchall()

    conn.close()
    return render_template(
        "admin/dashboard.html",
        stats=stats,
        recent_events=recent_events,
        recent_audit=recent_audit,
        cameras=cameras,
    )


# ── Events ────────────────────────────────────────────────────────


@admin_bp.route("/events")
@require_admin
def events():
    conn = _conn()
    rows = []
    if _table_exists(conn, "events"):
        rows = conn.execute(
            "SELECT event_id, event_type, source, message, timestamp "
            "FROM events ORDER BY timestamp DESC LIMIT 500"
        ).fetchall()
    conn.close()
    return render_template("admin/events.html", events=rows)


# ── Devices ───────────────────────────────────────────────────────


@admin_bp.route("/devices")
@require_admin
def devices():
    conn = _conn()
    cameras = []
    if _table_exists(conn, "detections"):
        cameras = conn.execute(
            "SELECT camera, COUNT(*) AS detections, MAX(timestamp) AS last_seen "
            "FROM detections GROUP BY camera ORDER BY last_seen DESC"
        ).fetchall()
    conn.close()
    return render_template("admin/devices.html", cameras=cameras)


# ── Unknown Faces ─────────────────────────────────────────────────


@admin_bp.route("/unknown-faces")
@require_admin
def unknown_faces():
    conn = _conn()
    rows = []
    if _table_exists(conn, "detections"):
        rows = conn.execute(
            "SELECT detection_id, camera, timestamp, snapshot_path "
            "FROM detections WHERE known_person = 0 "
            "ORDER BY timestamp DESC LIMIT 200"
        ).fetchall()
    conn.close()
    return render_template("admin/unknown_faces.html", faces=rows)


# ── Audit Log ─────────────────────────────────────────────────────


@admin_bp.route("/audit")
@require_admin
def audit_log():
    conn = _conn()
    rows = conn.execute(
        "SELECT admin_username, action, detail, ip, created_at "
        "FROM audit_log ORDER BY created_at DESC LIMIT 1000"
    ).fetchall()
    conn.close()
    return render_template("admin/audit.html", records=rows)


# ── Admin User Management (super_admin only) ──────────────────────


@admin_bp.route("/admins")
@require_admin
@require_role("super_admin")
def admin_users():
    conn = _conn()
    rows = conn.execute(
        "SELECT id, username, role, is_active, created_at, last_login "
        "FROM admin_users ORDER BY created_at"
    ).fetchall()
    conn.close()
    return render_template("admin/admin_users.html", admins=rows)


@admin_bp.route("/admins/create", methods=["GET", "POST"])
@require_admin
@require_role("super_admin")
def create_admin_user():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "admin")
        if role not in ("super_admin", "admin", "viewer"):
            role = "admin"
        if len(username) < 3:
            error = "Username must be at least 3 characters."
        elif len(password) < 10:
            error = "Password must be at least 10 characters."
        elif not create_admin(username, password, role):
            error = "Username already exists."
        else:
            audit("CREATE_ADMIN", f"{role}: {username}", request.remote_addr)
            flash(f"Admin user '{username}' created.", "success")
            return redirect(url_for("admin.admin_users"))
    return render_template("admin/create_admin.html", error=error)


@admin_bp.route("/admins/<int:admin_id>/toggle", methods=["POST"])
@require_admin
@require_role("super_admin")
def toggle_admin(admin_id: int):
    current = session["admin"]
    if current["id"] == admin_id:
        flash("You cannot suspend your own account.", "error")
        return redirect(url_for("admin.admin_users"))
    conn = _conn()
    row = conn.execute(
        "SELECT username, is_active FROM admin_users WHERE id = ?", (admin_id,)
    ).fetchone()
    if row:
        new_state = 0 if row[1] else 1
        conn.execute(
            "UPDATE admin_users SET is_active = ? WHERE id = ?", (new_state, admin_id)
        )
        conn.commit()
        action = "ACTIVATE_ADMIN" if new_state else "SUSPEND_ADMIN"
        audit(action, row[0], request.remote_addr)
    conn.close()
    return redirect(url_for("admin.admin_users"))


@admin_bp.route("/admins/<int:admin_id>/delete", methods=["POST"])
@require_admin
@require_role("super_admin")
def delete_admin_user(admin_id: int):
    current = session["admin"]
    if current["id"] == admin_id:
        flash("You cannot delete your own account.", "error")
        return redirect(url_for("admin.admin_users"))
    conn = _conn()
    row = conn.execute(
        "SELECT username FROM admin_users WHERE id = ?", (admin_id,)
    ).fetchone()
    if row:
        conn.execute("DELETE FROM admin_users WHERE id = ?", (admin_id,))
        conn.commit()
        audit("DELETE_ADMIN", row[0], request.remote_addr)
        flash(f"Admin user '{row[0]}' deleted.", "success")
    conn.close()
    return redirect(url_for("admin.admin_users"))


# ── System Config (read-only, no secrets) ─────────────────────────


@admin_bp.route("/config")
@require_admin
@require_role("super_admin")
def system_config():
    # Only safe, non-sensitive settings shown — never tokens or passwords
    config = {
        "app_name": settings.app_name,
        "app_version": settings.app_version,
        "debug": settings.debug,
        "log_level": settings.log_level,
        "database_path": settings.database_path,
        "camera_index": settings.camera_index,
        "telegram_bot_configured": bool(settings.telegram_bot_token),
    }
    return render_template("admin/config.html", config=config)
