"""
Admin authentication, RBAC decorators, and audit logging.
Uses werkzeug (already a Flask dependency — no new packages needed).
"""
import functools
import sqlite3
from datetime import datetime

from flask import flash, redirect, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from src.config.loader import load_settings

settings = load_settings()

ROLES = ("super_admin", "admin", "viewer")


# ── Database helpers ──────────────────────────────────────────────


def _conn() -> sqlite3.Connection:
    return sqlite3.connect(settings.database_path)


def init_admin_db() -> None:
    """Create admin tables if they don't exist. Safe to call on every startup."""
    conn = _conn()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS admin_users (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            username     TEXT    UNIQUE NOT NULL,
            password_hash TEXT   NOT NULL,
            role         TEXT    NOT NULL DEFAULT 'admin',
            is_active    INTEGER NOT NULL DEFAULT 1,
            created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
            last_login   TEXT
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id       INTEGER,
            admin_username TEXT,
            action         TEXT NOT NULL,
            detail         TEXT,
            ip             TEXT,
            created_at     TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """
    )
    conn.commit()
    conn.close()


# ── Admin user operations ─────────────────────────────────────────


def admin_count() -> int:
    conn = _conn()
    n = conn.execute("SELECT COUNT(*) FROM admin_users").fetchone()[0]
    conn.close()
    return n


def create_admin(username: str, password: str, role: str = "admin") -> bool:
    """Returns False if username already exists."""
    try:
        conn = _conn()
        conn.execute(
            "INSERT INTO admin_users (username, password_hash, role) VALUES (?, ?, ?)",
            (username, generate_password_hash(password), role),
        )
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        return False


def authenticate(username: str, password: str) -> dict | None:
    conn = _conn()
    row = conn.execute(
        "SELECT id, password_hash, role, is_active FROM admin_users WHERE username = ?",
        (username,),
    ).fetchone()
    conn.close()
    if row and row[3] == 1 and check_password_hash(row[1], password):
        return {"id": row[0], "username": username, "role": row[2]}
    return None


def set_last_login(admin_id: int) -> None:
    conn = _conn()
    conn.execute(
        "UPDATE admin_users SET last_login = ? WHERE id = ?",
        (datetime.now().isoformat(timespec="seconds"), admin_id),
    )
    conn.commit()
    conn.close()


# ── Audit ─────────────────────────────────────────────────────────


def audit(action: str, detail: str | None = None, ip: str | None = None) -> None:
    """Write an audit record. No-ops if no admin is in session."""
    admin = session.get("admin")
    if not admin:
        return
    conn = _conn()
    conn.execute(
        "INSERT INTO audit_log (admin_id, admin_username, action, detail, ip) "
        "VALUES (?, ?, ?, ?, ?)",
        (admin["id"], admin["username"], action, detail, ip),
    )
    conn.commit()
    conn.close()


# ── Decorators ────────────────────────────────────────────────────


def require_admin(f):
    """Redirect to login if no admin session."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin.login"))
        return f(*args, **kwargs)
    return wrapper


def require_role(*roles: str):
    """Allow only admins whose role is in *roles*."""
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            admin = session.get("admin")
            if not admin or admin["role"] not in roles:
                flash("Insufficient permissions.", "error")
                return redirect(url_for("admin.dashboard"))
            return f(*args, **kwargs)
        return wrapper
    return decorator
